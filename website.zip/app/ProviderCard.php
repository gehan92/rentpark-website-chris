<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProviderCard extends Model
{
    //
}
