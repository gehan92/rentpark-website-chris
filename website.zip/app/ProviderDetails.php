<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProviderDetails extends Model
{
    //
}
