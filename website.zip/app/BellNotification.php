<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\BellNotification;


class BellNotification extends Model
{
	//
}
