 

<?php $__env->startSection('title', tr('view_spaces')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.spaces.index')); ?>"><?php echo e(tr('parking_space')); ?></a></li>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.spaces.view', ['host_id' => $host_details->id])); ?>"><?php echo e(tr('view_spaces')); ?></a></li>
  
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('availability')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/css/space.css')); ?> ">   
    <!-- form time picke css-->
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/clockpicker/dist/jquery-clockpicker.min.css')); ?>"/>
    <!-- form checkbox css-->
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/icheck/skins/all.css')); ?>"/>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
			
	<div class="row">
	
		<div class="col-lg-12">
	
			<div class="card">

                <div class="card-header bg-card-header ">


                    <h4 class="text-uppercase"><b><?php echo e(tr('availability')); ?> - <a class="text-white" href="<?php echo e(route('admin.spaces.view', ['host_id' => $host_details->id])); ?>"><?php echo e($host_details->host_name); ?></a></b>

                    <button class="btn btn-secondary pull-right" type="button" onclick="$('#availability_add_form').toggle()"><i class="fa fa-plus"></i> <?php echo e(tr('add_availability')); ?></button>
                        
                    </h4>

                </div>


			  	<div class="card-body" id="availability_add_form" style="display: none">
			     		   
                    <form class="forms-sample" action="<?php echo e(Setting::get('is_demo_control_enabled') == NO ? route('admin.spaces.availability.save') : '#'); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <?php echo csrf_field(); ?>

                    <div class="card-body">                               
                        
                        <input type="hidden" name="host_id" value="<?php echo e($host_details->id); ?>">

                        <div class="row">

                            <div class="form-group col-md-4">

                                <label for="service_location_id"><?php echo e(tr('choose_days')); ?></label>

                                <select class="form-control select2" id="available_days" name="available_days" multiple>
                                    <option value=""><?php echo e(tr('available_days')); ?></option>

                                    <?php $__currentLoopData = $available_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week_day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($week_day['key']); ?>" <?php if( $week_day['is_selected']): ?> selected <?php endif; ?>>
                                            <?php echo e($week_day['value']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            </div>

                            <div class="form-group col-md-5">

                                <label for="type"><?php echo e(tr('status')); ?></label>

                                <select class="form-control select2" id="type" name="type">
                                    <option value="1"><?php echo e(tr('add_space_note')); ?></option> 

                                    <option value="0"><?php echo e(tr('remove_space_note')); ?></option>

                                </select>

                            </div>  

                            <div class="form-group col-md-3">

                                <label for="spaces"><?php echo e(tr('space_to_add_remove')); ?></label>

                                <input type="number" class="form-control" id="spaces" name="spaces" value="<?php echo e(old('spaces')); ?>" required>
                            </div>
                        
                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">

                                <label for="from_date"><?php echo e(tr('from_date')); ?></label>

                                <div class='input-group date' id='datetimepicker1'>
                                    <input type='date' class="form-control" id="from_date" name="from_date"/>
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>

                            </div> 

                            
                            <div class="form-group col-md-6">

                                <label for="to_date"><?php echo e(tr('to_date')); ?></label>

                                <div class='input-group date' id='datetimepicker1'>
                                    <input type='date' class="form-control" id="to_date" name="to_date" />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>

                            </div>                            

                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">

                                <label for="from_time"><?php echo e(tr('from_time')); ?></label>

                                <div class="form-group">
                                    
                                    <div class="input-group mb-2 mr-md-2 mb-md-0">
                                    
                                        <div class="form-group input-group clockpicker">
                                           <input type="time" id="from_time" name="from_time" class="form-control" value="">
                                        </div>

                                    </div>
                                
                                </div>

                            </div>
                            <div class="form-group col-md-6">

                                <label for="to_time"><?php echo e(tr('to_time')); ?></label>

                                <div class="form-group">
                                    
                                    <div class="input-group mb-2 mr-md-2 mb-md-0">
                                    
                                        <div class="form-group input-group clockpicker">
                                           <input type="time" id="to_time" name="to_time" class="form-control" value="">
                                        </div>

                                    </div>
                                
                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="card-footer">

                        <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                        <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <button type="submit" class="btn btn-success mr-2"><?php echo e(tr('submit')); ?> </button>

                        <?php else: ?>

                            <button type="button" class="btn btn-success mr-2" disabled><?php echo e(tr('submit')); ?></button>
                            
                        <?php endif; ?>

                    </div>

                    </form>

			    </div>

               <!--  <div class="card-header bg-card-header ">

                    <h4 class="text-uppercase"><b><?php echo e(tr('availability')); ?></b>

                    <button class="btn btn-secondary pull-right" type="button" onclick="$('#availability_add_form').toggle()"><i class="fa fa-plus"></i> <?php echo e(tr('add_availability')); ?></button>
                        
                    </h4>

                </div> -->
                    <hr>
                    <div class="card-body">
                        <h4><?php echo e(tr('availabilities')); ?></h4>

                        <div class="table-responsive">
                        
                            <table  class="table">
                            
                               <?php if($hosts_availability_list->count()): ?>

                                <thead>
                                  
                                    <tr>
                                        <th><?php echo e(tr('s_no')); ?></th>
                                        <th><?php echo e(tr('from_date')); ?></th>
                                        <th><?php echo e(tr('to_date')); ?></th>
                                        <th><?php echo e(tr('space_count')); ?></th>
                                        <th><?php echo e(tr('type')); ?></th>
                                        <th><?php echo e(tr('created_at')); ?></th>
                                        <th><?php echo e(tr('updated_at')); ?></th>
                                    </tr>
                               
                                </thead>                                    

                                <tbody>
                                    
                                    <?php $__currentLoopData = $hosts_availability_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h => $hosts_availability_list_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($h+1); ?></td>

                                        <td><?php echo e(common_date($hosts_availability_list_details->from_date)); ?></td>
                                      
                                        <td><?php echo e(common_date($hosts_availability_list_details->to_date)); ?></td>
                                      
                                        <td><?php echo e($hosts_availability_list_details->spaces); ?></td>

                                        <td>

                                            <?php if($hosts_availability_list_details->type == HOST_AVAIL_ADD_SPACE): ?>
                                            <?php echo e(tr('space_added')); ?>

                                            <?php elseif($hosts_availability_list_details->type == HOST_AVAIL_REMOVE_SPACE): ?>
                                            <?php echo e(tr('space_removed')); ?>

                                            <?php endif; ?>

                                        </td>
                                        
                                        <td><?php echo e(common_date($hosts_availability_list_details->created_at)); ?></td>
                                        
                                        <td><?php echo e(common_date($hosts_availability_list_details->updated_at)); ?></td>
                                        <td>                                    
                                            <a class="btn btn-danger" href="<?php echo e(route('admin.spaces.availability.delete', ['host_id'=>$host_details->id, 'hosts_availability_list_id' => $hosts_availability_list_details->id])); ?>">
                                                <?php echo e(tr('delete')); ?>

                                            </a>                                           
                                        </td>                           

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                                <?php else: ?>
                                    <?php echo e(tr('no_result_found')); ?>

                                <?php endif; ?>

                            </table>
                        
                        </div>

                    </div>
        
            </div>

        </div>

   </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });
</script>
        
<!-- form time picke js starts -->
    <script src="<?php echo e(asset('admin-assets/node_modules/clockpicker/dist/jquery-clockpicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin-assets/js/formpickers.js')); ?>"></script>
<!-- form time picke js ends -->

<script type="text/javascript">

//  @todo  saturdy and sunday working enquiery
$(":checkbox").click(function(){
    var id = $(this).attr('id');
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>