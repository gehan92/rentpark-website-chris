 

<?php $__env->startSection('title', tr('view_provider_subscriptions')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="#"><?php echo e(tr('provider_subscriptions')); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_provider_subscriptions')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12 grid-margin stretch-card">
      
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('view_provider_subscriptions')); ?>

                    <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.provider_subscriptions.create')); ?>">
                        <i class="fa fa-plus"></i><?php echo e(tr('add_provider_subscription')); ?>

                    </a>
                </h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">
                 
                    <table id="order-listing" class="table">
                 
                        <thead>
                            <tr>
                                <th><?php echo e(tr('id')); ?></th>
                                <th><?php echo e(tr('title')); ?></th>
                                <th><?php echo e(tr('amount')); ?></th>
                                <th><?php echo e(tr('plan')); ?></th> 
                                <!-- <th><?php echo e(tr('is_popular')); ?></th> -->
                                <th><?php echo e(tr('subscribers')); ?></th>
                                <th><?php echo e(tr('status')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $provider_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>  $provider_subscription_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td><?php echo e($i+1); ?></td>

                                    <td>    
                                        <a href="<?php echo e(route('admin.provider_subscriptions.view', ['provider_subscription_id' => $provider_subscription_details->id])); ?>" class=""> <?php echo e($provider_subscription_details->title); ?> </a> 
                                    </td>

                                    <td>
                                        <?php echo e(formatted_amount($provider_subscription_details->amount)); ?>

                                    </td>

                                    <td>
                                        <span class="label label-success"><?php echo e($provider_subscription_details->plan); ?>

                                        </span>
                                    </td>

                                    <td style="display: none;">

                                        <?php if($provider_subscription_details->is_popular == YES ): ?>

                                            <span class="label label-success"><?php echo e(tr('yes')); ?></span> 
                                        <?php else: ?>
                                            <span class="label label-warning"><?php echo e(tr('no')); ?></span> 

                                        <?php endif; ?>

                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('admin.provider_subscriptions.payments' ,['provider_subscription_id' => $provider_subscription_details->id])); ?>" class="btn btn-success btn-xs">

                                            <?php echo e($provider_subscription_details->subscriptionPayments->count()); ?> 

                                        </a>
                                    </td>

                                    <td>

                                        <?php if($provider_subscription_details->status == USER_APPROVED): ?>

                                            <span class="badge badge-outline-success"><?php echo e(tr('approved')); ?> </span>

                                        <?php else: ?>

                                            <span class="badge badge-outline-danger"><?php echo e(tr('declined')); ?> </span>

                                        <?php endif; ?>

                                    </td>

                                    <td>     

                                        <div class="template-demo">

                                            <div class="dropdown">

                                                <button class="btn btn-outline-primary  dropdown-toggle" type="button" id="dropdownMenuOutlineButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <?php echo e(tr('action')); ?>

                                                </button>

                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuOutlineButton1">
                                                   
                                                <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.view',['provider_subscription_id' => $provider_subscription_details->id] )); ?>"><?php echo e(tr('view')); ?></a>
                                                  
                                                <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.view',['provider_subscription_id' => $provider_subscription_details->id] )); ?>"> <?php echo e(tr('view')); ?> </a>

                                                <?php if(Setting::get('is_demo_control_enabled') == NO): ?>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.edit',['provider_subscription_id' => $provider_subscription_details->id] )); ?>">
                                                        <?php echo e(tr('edit')); ?>

                                                    </a>
                                                  
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.delete',['provider_subscription_id' => $provider_subscription_details->id] )); ?>" 
                                                    onclick="return confirm(&quot;<?php echo e(tr('provider_subscription_delete_confirmation' , $provider_subscription_details->title)); ?>&quot;);">
                                                        <?php echo e(tr('delete')); ?>

                                                    </a>

                                                <?php else: ?>

                                                    <a class="dropdown-item" href="javascript:;"><?php echo e(tr('edit')); ?></a>
                                                  
                                                    <a class="dropdown-item" href="javascript:;"><?php echo e(tr('delete')); ?></a> 

                                                <?php endif; ?>
                                               
                                                <div class="dropdown-divider"></div>

                                                <div class="dropdown-divider"></div>

                                                <?php if($provider_subscription_details->status == APPROVED): ?>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.status',['provider_subscription_id' => $provider_subscription_details->id] )); ?>" onclick="return confirm(&quot;<?php echo e($provider_subscription_details->title); ?>  <?php echo e(tr('provider_subscription_decline_confirmation')); ?>&quot;);" >
                                                        <?php echo e(tr('decline')); ?> 
                                                    </a>

                                                <?php else: ?>
                                                    
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.status',['provider_subscription_id' => $provider_subscription_details->id] )); ?>">
                                                        <?php echo e(tr('approve')); ?> 
                                                    </a>
                                                       
                                                <?php endif; ?>
                                                
                                                <div class="dropdown-divider"></div>


                                                <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.payments',['provider_subscription_id' => $provider_subscription_details->id] )); ?>"> 
                                                    <?php echo e(tr('payments')); ?>

                                                </a>

                                                </div>

                                            </div>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>

                    </table>
                    
                </div>

            </div>

        </div>
    
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>