<div class="col-lg-12 grid-margin stretch-card">

    <div class="row flex-grow">

        <div class="col-12 grid-margin">

            <div class="card">

                <form class="forms-sample" action="<?php echo e(Setting::get('is_demo_control_enabled') == NO ? route('admin.users.save') : '#'); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php echo csrf_field(); ?>

                    <div class="card-header bg-card-header">

                        <h4 class=""><?php echo e(tr('user')); ?>

                            <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.users.index')); ?>">
                                <i class="fa fa-eye"></i> <?php echo e(tr('view_users')); ?>

                            </a>
                            
                        </h4>

                    </div>

                    <div class="card-body">

                        <?php if($user_details->id): ?>

                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user_details->id); ?>">

                        <?php endif; ?>

                        <input type="hidden" name="login_by" id="login_by" value="<?php echo e($user_details->login_by ?: 'manual'); ?>">

                        <input type="hidden" name="billing_info_id" id="billing_info_id" value="<?php echo e($user_billing_info->id ?? ''); ?>">

                        <h4><?php echo e(tr('personal_details')); ?></h4><hr>
                        <div class="row">
                           
                            <div class="form-group col-md-6">
                                <label for="name"><?php echo e(tr('name')); ?> <span class="admin-required">*</span> </label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo e(tr('name')); ?>" value="<?php echo e(old('name') ?: $user_details->name); ?>" required>

                            </div>

                            <div class="form-group col-md-6">

                                <label for="mobile"><?php echo e(tr('mobile')); ?>  </label>

                                <input type="number" class="form-control" pattern="[0-9]{6,13}" id="mobile" name="mobile" placeholder="<?php echo e(tr('mobile')); ?>" value="<?php echo e(old('mobile') ?: $user_details->mobile); ?>">
                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">
                                <label for="email"><?php echo e(tr('email')); ?> <span class="admin-required">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo e(tr('email')); ?>" value="<?php echo e(old('email') ?: $user_details->email); ?>" required>
                            </div>

                            <?php if(!$user_details->id): ?>

                                <div class="form-group col-md-6">
                                    <label for="password"><?php echo e(tr('password')); ?> <span class="admin-required">*</span></label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="<?php echo e(tr('password')); ?>" value="<?php echo e(old('password')); ?>" required title="<?php echo e(tr('password_notes')); ?>">
                                </div>

                            <?php endif; ?>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">

                                <label><?php echo e(tr('upload_image')); ?></label>

                                <input type="file" name="picture" class="file-upload-default"  accept="image/*">

                                <div class="input-group col-xs-12">

                                    <input type="file" class="form-control file-upload-info" name="picture" placeholder="<?php echo e(tr('upload_image')); ?>">

                                    <div class="input-group-append">
                                        <button class="btn btn-info" type="button"><?php echo e(tr('upload')); ?></button>
                                    </div>
                          
                                </div>
                          
                            </div>

                        </div>

                        <h4><?php echo e(tr('account_details')); ?></h4><hr>
                        <div class="row">
                        
                            <div class="form-group col-md-6">
                                <label for="account_name"><?php echo e(tr('account_name')); ?></label>
                                <input type="text" class="form-control" id="account_name" name="account_name" placeholder="<?php echo e(tr('account_name')); ?>" value="<?php echo e($user_billing_info->account_name ?? ''); ?>">
                            </div> 
                            
                            <div class="form-group col-md-6">
                                <label for="paypal_email"><?php echo e(tr('paypal_email')); ?></label>
                                <input type="email" class="form-control" id="paypal_email" name="paypal_email" placeholder="<?php echo e(tr('paypal_email')); ?>" value="<?php echo e($user_billing_info->paypal_email ?? ''); ?>">
                            </div>

                        </div>

                        <div class="row">
                        
                            <div class="form-group col-md-6">
                                <label for="account_no"><?php echo e(tr('account_no')); ?></label>
                                <input type="number" class="form-control" id="account_no" name="account_no" placeholder="<?php echo e(tr('account_no')); ?>" value="<?php echo e($user_billing_info->account_no ?? ''); ?>">
                            </div> 
                            
                            <div class="form-group col-md-6">
                                <label for="route_no"><?php echo e(tr('route_no')); ?></label>
                                <input type="text" class="form-control" id="route_no" name="route_no" placeholder="<?php echo e(tr('route_no')); ?>" value="<?php echo e($user_billing_info->route_no ?? ''); ?>">
                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">

                                <label for="simpleMde"><?php echo e(tr('description')); ?></label>

                                <textarea class="form-control" id="description" name="description"><?php echo e(old('description') ?: $user_details->description); ?></textarea>

                            </div>

                        </div>

                    </div>

                    <div class="card-footer">

                        <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                        <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <button type="submit" class="btn btn-success mr-2"><?php echo e(tr('submit')); ?> </button>

                        <?php else: ?>

                            <button type="button" class="btn btn-success mr-2" disabled><?php echo e(tr('submit')); ?></button>
                            
                        <?php endif; ?>

                    </div>

                </form>

                </div>

            </div>

        </div>

    </div>
    
</div>