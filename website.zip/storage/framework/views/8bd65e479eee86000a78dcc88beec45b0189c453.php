 

<?php $__env->startSection('title', tr('view_service_location')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.service_locations.index')); ?>"><?php echo e(tr('service_location')); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_service_location')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-12">

            <!-- Card group -->
            <div class="card-group">


                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card image -->
                    <div class="view overlay">
                        <img class="card-img-top" src="<?php echo e($service_location_details->picture); ?>">
                        <a href="#!">
                            <div class="mask rgba-white-slight"></div>
                        </a>
                    </div>

                    <!-- Card content -->
                    <div class="card-body">

                        <!-- Title -->
                        <h4 class="card-title"><?php echo e(tr('description')); ?></h4>
                        <!-- Text -->
                        <p class="card-text"><?php echo e($service_location_details->description); ?></p>
                        
                    </div>
                    <!-- Card content -->

                </div>
                <!-- Card -->

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('service_location_name')); ?></h5>
                            
                            <p class="card-text"><?php echo e($service_location_details->name); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('service_location_center')); ?></h5>
                            
                            <p class="card-text"><?php echo e($service_location_details->address); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('latitude')); ?></h5>
                            
                            <p class="card-text"><?php echo e($service_location_details->latitude); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('longitude')); ?></h5>
                            
                            <p class="card-text"><?php echo e($service_location_details->longitude); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('radius')); ?></h5>
                            
                            <p class="card-text"><?php echo e($service_location_details->cover_radius); ?></p>

                        </div>

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('status')); ?></h5>
                            
                            <p class="card-text">

                                <?php if($service_location_details->status == APPROVED): ?>

                                    <span class="badge badge-success badge-md text-uppercase"><?php echo e(tr('approved')); ?></span>

                                <?php else: ?> 

                                    <span class="badge badge-danger badge-md text-uppercase"><?php echo e(tr('pending')); ?></span>

                                <?php endif; ?>
                            
                            </p>

                        </div>
                                                
                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('updated_at')); ?></h5>
                            
                            <p class="card-text"><?php echo e(common_date($service_location_details->updated_at)); ?></p>

                        </div>

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('created_at')); ?></h5>
                            
                            <p class="card-text"><?php echo e(common_date($service_location_details->created_at)); ?></p>

                        </div> 

                    </div>
                    <!-- Card content -->

                </div>

                <!-- Card -->

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <a href="<?php echo e(route('admin.service_locations.edit', ['service_location_id' => $service_location_details->id] )); ?>" class="btn btn-primary btn-block">
                                <?php echo e(tr('edit')); ?>

                            </a>

                            <a onclick="return confirm(&quot;<?php echo e(tr('service_location_delete_confirmation' , $service_location_details->name)); ?>&quot;);" href="<?php echo e(route('admin.service_locations.delete',['service_location_id' => $service_location_details->id] )); ?>"  class="btn btn-danger btn-block">
                                <?php echo e(tr('delete')); ?>

                            </a>

                        <?php else: ?>
                            <a href="javascript:;" class="btn btn-primary btn-block"><?php echo e(tr('edit')); ?></a>

                            <a href="javascript:;" class="btn btn-danger btn-block"><?php echo e(tr('delete')); ?></a>

                        <?php endif; ?>

                        <?php if($service_location_details->status == APPROVED): ?>

                            <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.service_locations.status', ['service_location_id' => $service_location_details->id] )); ?>" 
                            onclick="return confirm(&quot;<?php echo e($service_location_details->name); ?> - <?php echo e(tr('service_location_decline_confirmation')); ?>&quot;);"> 
                                <?php echo e(tr('decline')); ?>

                            </a>

                        <?php else: ?>

                            <a class="btn btn-success btn-block" href="<?php echo e(route('admin.service_locations.status', ['service_location_id' => $service_location_details->id] )); ?>">
                                <?php echo e(tr('approve')); ?>

                            </a>
                                                   
                        <?php endif; ?>
                        <a class="btn btn-success btn-block" href="<?php echo e(route('admin.spaces.index', ['service_location_id'=>$service_location_details->id])); ?>"> 
                        <?php echo e(tr('parking_space')); ?>

                        </a>  


                    </div>
                    <!-- Card content -->

                </div>
                <!-- Card -->
            </div>
            <!-- Card group -->

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>