 

<?php $__env->startSection('title', tr('view_provider_subscription')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.provider_subscriptions.index')); ?>"><?php echo e(tr('provider_subscriptions')); ?></a>
    </li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_provider_subscription')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>
    
    <div class="row">

        <div class="col-md-12">

            <!-- Card group -->
            <div class="card-group">

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card image -->
                   
                    <div class="card-body">

                        <div class="row">

                            <h5 class="col-md-12"><?php echo e(tr('title')); ?></h5>

                            <p class="col-md-12 text-muted"><?php echo e($provider_subscription_details->title); ?></p>

                            <?php if($provider_subscription_details->description): ?>

                                <h5 class="col-md-12"><?php echo e(tr('description')); ?></h5>

                                <p class="col-md-12 text-muted"><?php echo e($provider_subscription_details->description); ?></p>
                            <?php endif; ?>
                            
                        </div>

                        <hr>

                        <div class="row">

                            <div class="col-md-6">

                                <?php if(Setting::get('is_demo_control_enabled') == YES): ?>

                                    <a href="javascript:;" class="btn btn-primary btn-block"><?php echo e(tr('edit')); ?></a>

                                    <a href="javascript:;" class="btn btn-danger btn-block"><?php echo e(tr('delete')); ?></a>

                                <?php else: ?>

                                    <a class="btn btn-primary btn-block" href="<?php echo e(route('admin.provider_subscriptions.edit',['provider_subscription_id' => $provider_subscription_details->id])); ?>"><?php echo e(tr('edit')); ?></a>

                                    <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.provider_subscriptions.delete',['provider_subscription_id' => $provider_subscription_details->id] )); ?>" onclick="return confirm(&quot;<?php echo e(tr('provider_subscription_delete_confirmation' , $provider_subscription_details->title)); ?>&quot;);"><?php echo e(tr('delete')); ?></a>

                                <?php endif; ?>

                            </div>
                            
                            <div class="col-md-6">

                                <?php if($provider_subscription_details->status == APPROVED): ?>

                                    <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.provider_subscriptions.status', ['provider_subscription_id' => $provider_subscription_details->id])); ?>" onclick="return confirm(&quot;<?php echo e($provider_subscription_details->title); ?> <?php echo e(tr('provider_subscription_decline_confirmation')); ?>&quot;);" >
                                        <?php echo e(tr('decline')); ?> 
                                    </a>

                                <?php else: ?>
                                    
                                    <a class="btn btn-success btn-block" href="<?php echo e(route('admin.provider_subscriptions.status', ['provider_subscription_id' => $provider_subscription_details->id] )); ?>">
                                        <?php echo e(tr('approve')); ?> 
                                    </a>
                                       
                                <?php endif; ?>

                            </div>

                        </div>

                    
                    </div>

                </div>
                <!-- Card -->

                <!-- Card -->
                <div class="card mb-8">

                    <!-- Card content -->
                    <div class="card-body">

                        <div class="template-demo">

                            <table class="table mb-0">

                                <tbody>

                                    <tr>
                                        <td class="pl-0"><b><?php echo e(tr('title')); ?></b></td>
                                        <td class="pr-0 text-right"><div ><?php echo e($provider_subscription_details->title); ?></div></td>
                                    </tr> 

                                    <tr>
                                        <td class="pl-0"><b><?php echo e(tr('amount')); ?></b></td>
                                        <td class="pr-0 text-right"><div ><?php echo e(formatted_amount($provider_subscription_details->amount)); ?></div></td>
                                    </tr> 

                                    <tr>
                                        <td class="pl-0"><b><?php echo e(tr('plan')); ?></b></td>
                                        <td class="pr-0 text-right"><div ><?php echo e($provider_subscription_details->plan); ?></div></td>
                                    </tr> 

                                    <tr>
                                        <td class="pl-0"><b><?php echo e(tr('plan_type')); ?></b></td>
                                        <td class="pr-0 text-right"><div ><?php echo e($provider_subscription_details->plan_type); ?></div></td>
                                    </tr> 

                                    <tr style="display: none;"> 
                                        <td class="pl-0"><b><?php echo e(tr('is_popular')); ?></b></td>
                                        
                                        <td class="pr-0 text-right">
                                            <?php if($provider_subscription_details->is_popular == YES): ?>
                                                <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('yes')); ?></span>
                                            <?php else: ?>
                                                <span class="card-text  badge badge-danger badge-md text-uppercase"><?php echo e(tr('no')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="pl-0"><b><?php echo e(tr('total_subscribers')); ?></b></td>
                                        <td class="pr-0 text-right">
                                            <div>
                                                <a href="<?php echo e(route('admin.provider_subscriptions.payments' ,['provider_subscription_id' => $provider_subscription_details->id])); ?>" class="btn btn-success btn-xs">

                                                    <?php echo e($provider_subscription_details->total_subscriptions); ?> 
                                                </a>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="pl-0"><b><?php echo e(tr('revenue')); ?></b></td>
                                        <td class="pr-0 text-right">
                                            <div>
                                                <?php echo e(formatted_amount($provider_subscription_details->total_revenue)); ?> 
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="pl-0"> <b><?php echo e(tr('created_at')); ?></b></td>
                                        <td class="pr-0 text-right"><div><?php echo e(common_date($provider_subscription_details->created_at, Auth::check() ? Auth::guard('admin')->user()->timezone : 0)); ?></div></td>
                                    </tr>

                                    <tr>
                                        <td class="pl-0"> <b><?php echo e(tr('updated_at')); ?></b></td>
                                        <td class="pr-0 text-right"><div><?php echo e(common_date($provider_subscription_details->updated_at, Auth::check() ? Auth::guard('admin')->user()->timezone : 0)); ?></div></td>
                                    </tr>

                                </tbody>
                            
                            </table>

                        </div>
                        <!-- </div> -->

                    </div>
                    <!-- Card content -->

                </div>

                <!-- Card -->

            </div>
            <!-- Card group -->

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>