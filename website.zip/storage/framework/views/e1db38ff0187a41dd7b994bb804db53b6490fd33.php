 

<?php $__env->startSection('title', tr('view_static_page')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.static_pages.index')); ?>"><?php echo e(tr('static_pages')); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_static_page')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-12">

            <!-- Card group -->
            <div class="card-group">

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <!-- Title -->
                        <h4 class="card-title"><?php echo e(tr('description')); ?></h4>
                        <!-- Text -->
                        <p class="card-text"><?= $static_page_details->description ?></p>
                        
                    </div>
                    <!-- Card content -->

                </div>
                <!-- Card -->

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('title')); ?></h5>
                            
                            <p class="card-text"><?php echo e($static_page_details->title); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('section_type')); ?></h5>
                            
                            <p class="card-text"><?php echo e(static_page_footers($static_page_details->section_type, $is_list = NO)); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('status')); ?></h5>
                            
                            <p class="card-text">

                                <?php if($static_page_details->status == APPROVED): ?>

                                    <span class="badge badge-success badge-md text-uppercase"><?php echo e(tr('approved')); ?></span>

                                <?php else: ?> 

                                    <span class="badge badge-danger badge-md text-uppercase"><?php echo e(tr('pending')); ?></span>

                                <?php endif; ?>
                            
                            </p>

                        </div>
                                                
                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('updated_at')); ?></h5>
                            
                            <p class="card-text"><?php echo e(common_date($static_page_details->updated_at)); ?></p>

                        </div>

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('created_at')); ?></h5>
                            
                            <p class="card-text"><?php echo e(common_date($static_page_details->created_at)); ?></p>

                        </div> 

                        <div class="custom-card">
                            <div class="row">
                                
                            
                            <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                                <div class="col-md-4 col-lg-4">

                                    <a href="<?php echo e(route('admin.static_pages.edit', ['static_page_id'=> $static_page_details->id] )); ?>" class="btn btn-primary btn-block"><?php echo e(tr('edit')); ?></a>
                                    
                                </div>                              

                                <div class="col-md-4 col-lg-4">
                                    <a onclick="return confirm(&quot;<?php echo e(tr('static_page_delete_confirmation' , $static_page_details->title)); ?>&quot;);" href="<?php echo e(route('admin.static_pages.delete', ['static_page_id'=> $static_page_details->id] )); ?>" class="btn btn-danger btn-block">
                                        <?php echo e(tr('delete')); ?>

                                    </a>

                                </div>                               

                            <?php else: ?>
                            
                                <div class="col-md-4 col-lg-4">
                                    
                                    <button class="btn btn-primary btn-block" disabled><?php echo e(tr('edit')); ?></button>

                                </div>
                                
                                <div class="col-md-4 col-lg-4">
                                    
                                    <button class="btn btn-warning btn-block" disabled><?php echo e(tr('delete')); ?></button>
                                </div>
                                

                            <?php endif; ?>

                            <?php if($static_page_details->status == APPROVED): ?>

                                <div class="col-md-4 col-lg-4">
                                    
                                    <a class="btn btn-warning btn-block" href="<?php echo e(route('admin.static_pages.status', ['static_page_id'=> $static_page_details->id] )); ?>" onclick="return confirm(&quot;<?php echo e($static_page_details->title); ?>-<?php echo e(tr('static_page_decline_confirmation' , $static_page_details->title)); ?>&quot;);">

                                        <?php echo e(tr('decline')); ?>

                                    </a>
                                </div>

                            <?php else: ?>

                                <div class="col-md-4 col-lg-4">
                                     <a class="btn btn-success btn-block" href="<?php echo e(route('admin.static_pages.status', ['static_page_id'=> $static_page_details->id] )); ?>">
                                        <?php echo e(tr('approve')); ?>

                                    </a>
                                </div>
                                   
                            <?php endif; ?>

                            </div>

                        </div>

                    </div>
                    <!-- Card content -->

                </div>

                <!-- Card -->

            </div>

            <!-- Card group -->

        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>