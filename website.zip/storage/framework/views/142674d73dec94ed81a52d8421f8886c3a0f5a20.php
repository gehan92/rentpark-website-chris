<?php $__env->startSection('title', tr('documents')); ?>

<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item">
    <a href="<?php echo e(route('admin.providers.index')); ?>"><?php echo e(tr('providers')); ?></a>
</li>
<li class="breadcrumb-item active" aria-current="page">
    <span><?php echo e(tr('documents')); ?></span>
</li>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

<div class="col-lg-12 grid-margin stretch-card">
    
    <div class="card">
        
        <div class="card-header bg-card-header">

            <h4 class=""><?php echo e(tr('documents')); ?>

                <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.providers.index')); ?>">
                    <i class="fa fa-eye"></i> <?php echo e(tr('view_providers')); ?>

                </a>
                
            </h4>

        </div>
    
        <div class="card-body">


            <div class="table-responsive">
              
                <table id="order-listing" class="table">
                    
                    <thead>
                        <tr>
                            <th><?php echo e(tr('id')); ?></th>
                            <th><?php echo e(tr('provider')); ?></th>
                            <th><?php echo e(tr('documents')); ?></th>                            
                            <th><?php echo e(tr('action')); ?></th>                            
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $provider_documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $provider_document_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td><?php echo e($index+1); ?></td>

                            <td>
                                <a href="<?php echo e(route('admin.providers.view', ['provider_id' => $provider_document_details->provider_id])); ?>"><?php echo e($provider_document_details->providerDetails->name ??  "-"); ?></a>
                            </td>

                            <td>
                                <a href="<?php echo e(route('admin.documents.view',['document_id' => $provider_document_details->document_id ])); ?>"><?php echo e($provider_document_details->documentDetails->name ?? "-"); ?></a>
                            </td>

                            <td>
                                <a href="<?php echo e(route('admin.providers.documents.view',['provider_id' => $provider_document_details->provider_id ])); ?>"><span class="btn btn-info btn-large"><?php echo e(tr('view')); ?></span>
                                </a>
                            </td>
                            
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
            
            </div>
        
        </div>
    
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>