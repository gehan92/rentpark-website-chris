<?php $__env->startSection('title', tr('edit_service_location')); ?>

<?php $__env->startSection('breadcrumb'); ?>
	
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.service_locations.index')); ?>"><?php echo e(tr('service_locations')); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('edit_service_location')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('admin.service_locations._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    
    var autocomplete;
    var s_latitude = document.getElementById('latitude');
    var s_longitude = document.getElementById('longitude');

    function geolocate() {
        
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('my-dest')),
            {types: ['geocode']});

        autocomplete.addListener('place_changed', function(event) {

            var place = autocomplete.getPlace();

            if ( place.hasOwnProperty('place_id') ) {

                if (!place.geometry) {
                    
                    alert("Autocomplete's returned place contains no geometry");
                    document.getElementById('my-dest').value = '';
                    return;
                }

                s_latitude.value = place.geometry.location.lat();
                s_longitude.value = place.geometry.location.lng();            
            } 

        });
    }

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>