    <div class="row">
    
    <div class="col-12 grid-margin">

        <div class="card card-outline-info">

            <div class="card-body">
                <h4 class="card-title"> <?php echo $__env->yieldContent('title'); ?> </h4>

                <hr>

                <form class="forms-sample" id="example-form" action="<?php echo e(route('admin.spaces.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <?php echo csrf_field(); ?>

                    <div>

                        <input type="hidden" name="host_id" value="<?php echo e($host_details->id); ?>">

                        <h3 class="text-uppercase"><?php echo e(tr('space_details')); ?></h3>

                        <section>

                            <h4 class="heading_color"><?php echo e(tr('location_details')); ?></h4><hr>
                           
                            <div class="row">

                                <div class="col-md-4">

                                    <div class="form-group">

                                        <label for="service_location_id"><?php echo e(tr('choose_service_location')); ?></label>

                                        <select class="form-control select2" id="service_location_id" name="service_location_id">
                                            <option value=""><?php echo e(tr('choose_service_location')); ?></option>

                                            <?php $__currentLoopData = $service_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_location_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service_location_details->id); ?>"<?php if($service_location_details->is_selected == YES): ?> selected <?php endif; ?>>
                                                    <?php echo e($service_location_details->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    
                                    </div>

                                </div>

                                <div class="col-md-8">

                                    <div class="form-group">

                                        <label for="full_address"><?php echo e(tr('choose_location')); ?></label>

                                        <input type="text" class="form-control"  id="full_address" onFocus="geolocate()" name="full_address" placeholder="<?php echo e(tr('choose_location')); ?>" value="<?php echo e(old('full_address') ?: $host_details->full_address); ?>" required>

                                        <input type="hidden" name="latitude" id="latitude" value="<?php echo e(old('latitude') ?: $host_details->latitude); ?>">

                                        <input type="hidden" name="longitude" id="longitude" value="<?php echo e(old('longitude') ?: $host_details->longitude); ?>">
                                    
                                    </div>

                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="street_details"><?php echo e(tr('street_details')); ?></label>
                                        <input id="street_details" name="street_details" type="text" class="required form-control" value="<?php echo e(old('street_details') ?: $host_details->street_details); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="city"><?php echo e(tr('city')); ?></label>
                                        <input id="city" name="city" type="text" class="required form-control" value="<?php echo e(old('city') ?:  $host_details->city); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="state"><?php echo e(tr('state')); ?></label>
                                        <input id="state" name="state" type="text" class="required form-control" value="<?php echo e(old('state') ?: $host_details->state); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="zipcode"><?php echo e(tr('zipcode')); ?></label>
                                        <input id="zipcode" name="zipcode" type="text" class="required form-control" value="<?php echo e(old('zipcode') ?: $host_details->zipcode); ?>">
                                    </div>
                                </div>
                            </div>
                            <br>
                            <h4 class="heading_color"><?php echo e(tr('space_details_text')); ?></h4><hr>
                            <div class="row">
                                <div class="col-md-4">

                                    <div class="form-group">

                                        <label for="provider_id"><?php echo e(tr('providers')); ?></label>

                                        <select class="form-control select2" id="provider_id" name="provider_id">
                                            <option value=""><?php echo e(tr('choose_provider')); ?></option>
                                            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($provider->id); ?>"<?php if($provider->is_selected == YES): ?> selected <?php endif; ?>>
                                                    <?php echo e($provider->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="host_name"><?php echo e(tr('space_name')); ?> *</label>
                                        <input id="host_name" name="host_name" type="text" class="required form-control" value="<?php echo e(old('host_name') ?: $host_details->host_name); ?>">
                                    </div>
                                </div>

                                <div class=" col-md-4">
                                   
                                    <div class="form-group">

                                        <label for="host_type"><?php echo e(tr('choose_host_type')); ?></label>

                                        <select class="form-control select2" id="host_type" name="host_type">

                                            <option value=""><?php echo e(tr('choose_host_type')); ?></option>

                                            <?php $__currentLoopData = $host_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host_type_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($host_type_details->key); ?>" <?php if($host_type_details->is_selected == YES): ?> selected <?php endif; ?>><?php echo e($host_type_details->value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>

                                    </div>
                                
                                </div>

                                <div class=" col-md-4">
                                   
                                    <div class="form-group">

                                        <label for="category"><?php echo e(tr('host_owner_type')); ?></label>

                                        <select class="form-control select2" id="host_owner_type" name="host_owner_type">

                                            <option value=""><?php echo e(tr('host_owner_type')); ?></option>

                                            <?php $__currentLoopData = $host_owner_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host_owner_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($host_owner_type->key); ?>" <?php if($host_owner_type->is_selected == YES): ?> selected <?php endif; ?>><?php echo e($host_owner_type->value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                               
                                    </div>
                               
                                </div>

                                <div class="col-md-4">

                                    <div class="form-group">

                                        <label><?php echo e(tr('total_spaces')); ?>* </label>

                                        <input type="number" name="total_spaces" class="form-control" value="<?php echo e(old('total_spaces') ?: 1); ?>">

                                    </div>

                                </div>

                                <div class="col-md-12">

                                    <div class="form-group">

                                        <label for="description"><?php echo e(tr('description')); ?> *</label>

                                        <textarea id="description" name="description" class="form-control"><?php echo e(old('description') ?: $host_details->description); ?></textarea>
                                    
                                    </div>

                                </div>


                            </div>
                          
                            
                        </section>

                        <h3 class="text-uppercase"><?php echo e(tr('host_location_images')); ?></h3>

                        <section>

                            <h4 class="heading_color"><?php echo e(tr('host_upload_images')); ?></h4><hr>

                            <div class="row">
                                
                                <div class="form-group col-md-12">

                                    <label><?php echo e(tr('images')); ?></label>

                                    <input type="file" class="form-control" name="picture" multiple accept="image/*" placeholder="<?php echo e(tr('upload_image')); ?>">

                                </div>
                                
                            </div>

                            <div class="row">
                                
                                <div class="form-group col-md-12">

                                    <label><?php echo e(tr('gallery')); ?></label>

                                    <input type="file" class="form-control" name="pictures[]" multiple accept="image/*" placeholder="<?php echo e(tr('gallery_image')); ?>">

                                </div>

                            </div>
                        
                        </section>

                        <h3 class="text-uppercase"><?php echo e(tr('host_pricing_details')); ?></h3>

                        <section>
                            <h4 class="heading_color"><?php echo e(tr('pricing_details')); ?></h4>
                            <hr>
                            
                            <div class="row">

                                <div class="col-md-4">

                                    <div class="form-group">
                                        <label><?php echo e(tr('per_hour')); ?> *</label>
                                        <input type="number" min="0" name="per_hour" required value="<?php echo e(old('per_hour') ?: $host_details->per_hour); ?>">
                                    </div>

                                </div>

                                <div class="col-md-4">

                                    <div class="form-group">
                                        <label><?php echo e(tr('per_day')); ?> *</label>
                                        <input type="number" min="0" min="0" name="per_day" value="<?php echo e(old('per_day') ?: $host_details->per_day); ?>">
                                    </div>

                                </div>

                                <div class="col-md-4">

                                    <div class="form-group">
                                        <label><?php echo e(tr('per_week')); ?> *</label>
                                        <input type="number" min="0" name="per_week" value="<?php echo e(old('per_week') ?: $host_details->per_week); ?>">
                                    </div>

                                </div>

                                <div class="col-md-4">

                                    <div class="form-group">
                                        <label><?php echo e(tr('per_month')); ?> *</label>
                                        <input type="number" min="0" name="per_month" value="<?php echo e(old('per_month') ?: $host_details->per_month); ?>">

                                    </div>

                                </div>

                            </div>

                            <br>
                       
                            <h4 class="heading_color"><?php echo e(tr('access_method')); ?></h4><hr>
                      
                            <div class="row">
                                
                                <div class="form-group col-6">

                                    <label><?php echo e(tr('access_method_key')); ?> *</label>

                                    <div class="switch-field">

                                        <input type="radio" id="secret_code" name="access_method" value="<?php echo e(ACCESS_METHOD_SECRET_CODE); ?>" <?php if($host_details->access_method == ACCESS_METHOD_SECRET_CODE): ?> checked <?php endif; ?>/>
                                        <label for="secret_code">
                                            <?php echo e(tr('secret_code')); ?>

                                        </label>

                                        <input id="access_method_key" name="access_method" type="radio" value="<?php echo e(ACCESS_METHOD_KEY); ?>" <?php if($host_details->access_method == ACCESS_METHOD_KEY): ?> checked <?php endif; ?>>

                                        <label for="access_method_key">
                                            <?php echo e(tr('access_method_key')); ?>

                                        </label>

                                    </div>

                                </div>
                               
                                <div class="col-md-12">

                                    <div class="form-group">

                                        <label for="description"><?php echo e(tr('access_note')); ?> *</label>

                                        <textarea class="form-control" id="access_note" name="access_note"><?php echo e(old('access_note') ?: $host_details->access_note); ?></textarea>
                                    
                                    </div>

                                </div>

                            </div>
                            
                        </section>

                        <h3>Finish</h3>

                        <section>
                           
                            <h4>Terms and conditions</h4>
                           
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="checkbox" type="checkbox" checked > I agree with the Terms and Conditions.
                                </label>
    
                            </div>
    
                        </section>
    
                    </div>
    
                </form>
    
            </div>
    
        </div>
    
    </div>

</div>

