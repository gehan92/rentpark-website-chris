<?php $__env->startSection('title', tr('login')); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container-scroller">
	    <div class="container-fluid page-body-wrapper">
	        <div class="row">
	            <div class="content-wrapper full-page-wrapper d-flex align-items-center auth login-full-bg" style="background: #3a3f51 !important">
	                <div class="row w-100">
	                    <div class="col-lg-4 mx-auto">
	                        <div class="auth-form-dark text-left p-5">
	                            
	                            <h2><?php echo e(tr('login')); ?></h2>

	                            <h4 class="font-weight-light"><?php echo e(tr('hello_text')); ?></h4>

	                            <?php echo $__env->make('notifications.notify', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	                            <form class="pt-5" action="<?php echo e(route('admin.login.post')); ?>" method="POST">

	                            	<?php echo csrf_field(); ?>

	                                <div class="form-group">

	                                    <label for="email"><?php echo e(tr('email')); ?></label>

	                                    <input type="email" name="email" class="form-control" id="email" placeholder="<?php echo e(tr('email')); ?>" value="<?php echo e(old('email') ?: Setting::get('demo_admin_email')); ?>" autocomplete="off">

	                                    <i class="mdi mdi-account"></i>

	                                    <?php if($errors->has('email')): ?>
										    <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
										<?php endif; ?>

	                                </div>
	                                
	                                <div class="form-group">

	                                    <label for="password"><?php echo e(tr('password')); ?></label>

	                                    <input type="password" name="password" class="form-control" id="password" placeholder="<?php echo e(tr('password')); ?>" value="<?php echo e(old('password') ?: Setting::get('demo_admin_password')); ?>">

	                                    <i class="mdi mdi-eye"></i>

	                                    <?php if($errors->has('password')): ?>
										    <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
										<?php endif; ?>

	                                </div>

	                                <div class="mt-5">	                
	                                    <button style="background: green;color: white;" type="submit" class="btn btn-block btn-success btn-lg font-weight-medium" ><?php echo e(tr('login')); ?></button>
	                                </div>

	                            </form>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <!-- content-wrapper ends -->
	        </div>
	        <!-- row ends -->
	    </div>
	    <!-- page-body-wrapper ends -->
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.focused', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>