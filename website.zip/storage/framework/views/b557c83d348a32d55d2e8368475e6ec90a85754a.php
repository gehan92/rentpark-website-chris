<?php $__env->startSection('title', tr('edit_user')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(tr('users')); ?></a></li>
    
    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('edit_user')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('admin.users._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>