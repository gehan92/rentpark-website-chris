 

<?php $__env->startSection('title'); ?>

<?php echo e($page_title); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.spaces.index')); ?>"><?php echo e(tr('parking_space')); ?></a></li>
    
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_spaces')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

<div class="col-lg-12 grid-margin stretch-card">
    
    <div class="card">

        <div class="card-header bg-card-header ">

            <h4 class="text-uppercase"><b><?php echo e($page_title); ?></b>

                <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.spaces.create')); ?>">
                    <i class="fa fa-plus"></i> <?php echo e(tr('add_space')); ?>

                </a>
            </h4>

        </div>

        <div class="card-body">

            <div class="table-responsive">
            
                <table id="order-listing" class="table">
                   
                    <thead>
                        <tr>
                            <th><?php echo e(tr('s_no')); ?></th>
                            <th><?php echo e(tr('space_name')); ?></th>
                            <th><?php echo e(tr('provider')); ?></th>
                            <th><?php echo e(tr('location')); ?></th>
                            <th><?php echo e(tr('status')); ?></th>
                            <th><?php echo e(tr('verify')); ?></th>
                            <th><?php echo e(tr('action')); ?></th>
                        </tr>
                 
                    </thead>

                    <tbody>
                        
                    	<?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h => $host_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	                    	<tr>
	                    		<td><?php echo e($h+1); ?></td>

	                    		<td>
                                    <a href="<?php echo e(route('admin.spaces.view', ['host_id' => $host_details->id])); ?>"><?php echo e($host_details->host_name); ?></a>
	                    			<br>
                                    <br><small class="text-gray"><?php echo e(common_date($host_details->updated_at)); ?></small>
	                    		</td>

	                    		<td>
                                    <a href="<?php echo e(route('admin.providers.view', ['provider_id' => $host_details->provider_id])); ?>">
                                        <?php echo e($host_details->provider_name); ?>

                                    </a>
                                </td>

	                    		<td>
                                    <a href="<?php echo e(route('admin.service_locations.view' , ['service_location_id' => $host_details->service_location_id] )); ?>"><?php echo e($host_details->location); ?></a>
                                </td>

	                    		<td>

	                    			<?php if($host_details->admin_status == ADMIN_HOST_APPROVED): ?> 

                                        <span class="badge badge-outline-success">
                                        	<?php echo e(tr('ADMIN_HOST_APPROVED')); ?> 
                                        </span>

                                    <?php else: ?>

                                        <span class="badge badge-outline-warning">
                                        	<?php echo e(tr('ADMIN_HOST_PENDING')); ?> 
                                        </span>

                                    <?php endif; ?>

                                    <br>
                                    
                                    <br>

                                    <?php if($host_details->status == HOST_OWNER_PUBLISHED): ?> 

                                        <span class="badge badge-success">
                                        	<?php echo e(tr('HOST_OWNER_PUBLISHED')); ?> 
                                        </span>

                                    <?php else: ?>

                                        <span class="badge badge-danger">
                                        	<?php echo e(tr('HOST_OWNER_UNPUBLISHED')); ?> 
                                        </span>

                                    <?php endif; ?>

	                    		</td>
	                    		
                                <td>

	                    			<?php if($host_details->is_admin_verified == ADMIN_HOST_VERIFIED): ?> 

                                        <span class="badge badge-outline-success">
                                        	<?php echo e(tr('verified')); ?> 
                                        </span>

                                    <?php else: ?>

                                        <a class="badge badge-info" href="<?php echo e(route('admin.spaces.verification_status', ['host_id' => $host_details->id])); ?>"> 
                                            <?php echo e(tr('verify')); ?> 
                                        </a>

                                    <?php endif; ?>

	                    		</td>
	                    		

	                    		<td>                                    
                                   
                                    <div class="template-demo">
                                   
                                        <div class="dropdown">
                                   
                                            <button class="btn btn-outline-primary  dropdown-toggle btm-sm" type="button" id="dropdownMenuOutlineButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php echo e(tr('action')); ?>

                                            </button>
                                   
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuOutlineButton1">

                                                <a class="dropdown-item" href="<?php echo e(route('admin.spaces.view', ['host_id' => $host_details->id])); ?>">
                                                    <?php echo e(tr('view')); ?>

                                                </a>
                                                  
                                                <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                                                
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.spaces.edit', ['host_id' => $host_details->id])); ?>">
                                                        <?php echo e(tr('edit')); ?>

                                                    </a>
                                                    
                                                    <a class="dropdown-item" onclick="return confirm(&quot;<?php echo e(tr('host_delete_confirmation' , $host_details->name)); ?>&quot;);" href="<?php echo e(route('admin.spaces.delete', ['host_id' => $host_details->id])); ?>">

                                                        <?php echo e(tr('delete')); ?>

                                                    </a>

                                                <?php else: ?>

                                                    <a class="dropdown-item" href="javascript:;">
                                                        <?php echo e(tr('edit')); ?>

                                                    </a>

                                                    <a class="dropdown-item" href="javascript:;">
                                                        <?php echo e(tr('delete')); ?>

                                                    </a>

                                                <?php endif; ?>

                                                <div class="dropdown-divider"></div>
                                            
                                                <?php if($host_details->admin_status == APPROVED): ?>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.spaces.status', ['host_id' => $host_details->id] )); ?>" 
                                                    onclick="return confirm(&quot;<?php echo e($host_details->host_name); ?> - <?php echo e(tr('host_decline_confirmation')); ?>&quot;);"> 
                                                        <?php echo e(tr('decline')); ?>

                                                    </a>

                                                <?php else: ?>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.spaces.status', ['host_id' => $host_details->id] )); ?>">
                                                        <?php echo e(tr('approve')); ?>

                                                    </a>
                                                       
                                                <?php endif; ?>

                                                <div class="dropdown-divider"></div>

                                                <a class="dropdown-item"href="<?php echo e(route('admin.spaces.availability.create', ['host_id' => $host_details->id] )); ?>">
                                                    <?php echo e(tr('availability')); ?>

                                                </a>

                                                <a class="dropdown-item" href="<?php echo e(route('admin.spaces.gallery.index', ['host_id' => $host_details->id] )); ?>">
                                                        <?php echo e(tr('gallery')); ?>

                                                </a>

                                            </div>
                                
                                        </div>
                                
                                    </div>
                                
                                </td>	                    	

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                             
                    </tbody>

                </table>
            
            </div>

        </div>
    
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>