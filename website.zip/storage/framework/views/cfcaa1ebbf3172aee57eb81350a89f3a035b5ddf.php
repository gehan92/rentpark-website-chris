<?php $__env->startSection('title', tr('add_static_page')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item">
    	<a href="<?php echo e(route('admin.static_pages.index')); ?>"><?php echo e(tr('static_pages')); ?></a>
    </li>
    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('add_static_page')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('admin.static_pages._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="https://cdn.ckeditor.com/ckeditor5/11.1.1/classic/ckeditor.js"></script>

<script>
    ClassicEditor
        .create( document.querySelector( '#ckeditor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>