 

<?php $__env->startSection('title', tr('view_document')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.documents.index')); ?>"><?php echo e(tr('documents')); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_document')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-12">

            <!-- Card group -->
            <div class="card-group">

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <!-- Title -->
                        <h4 class="card-title"><?php echo e(tr('description')); ?></h4>
                        <!-- Text -->
                        <p class="card-text"><?php echo e($document_details->description); ?></p>
                        
                    </div>
                    <!-- Card content -->

                </div>
                <!-- Card -->

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('name')); ?></h5>
                            
                            <p class="card-text"><?php echo e($document_details->name); ?></p>

                        </div> 

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('status')); ?></h5>
                            
                            <p class="card-text">

                                <?php if($document_details->status == APPROVED): ?>

                                    <span class="badge badge-success badge-md text-uppercase"><?php echo e(tr('approved')); ?></span>

                                <?php else: ?> 

                                    <span class="badge badge-danger badge-md text-uppercase"><?php echo e(tr('pending')); ?></span>

                                <?php endif; ?>
                            
                            </p>

                        </div>
                                                
                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('updated_at')); ?></h5>
                            
                            <p class="card-text"><?php echo e(common_date($document_details->updated_at)); ?></p>

                        </div>

                        <div class="custom-card">
                        
                            <h5 class="card-title"><?php echo e(tr('created_at')); ?></h5>
                            
                            <p class="card-text"><?php echo e(common_date($document_details->created_at)); ?></p>

                        </div> 

                    </div>
                    <!-- Card content -->

                </div>

                <!-- Card -->

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                        
                            <a href="<?php echo e(route('admin.documents.edit',['document_id' => $document_details->id] )); ?>" class="btn btn-primary btn-block">
                                <?php echo e(tr('edit')); ?>

                            </a>

                            <a onclick="return confirm(&quot;<?php echo e(tr('document_delete_confirmation' , $document_details->name)); ?>&quot;);" href="<?php echo e(route('admin.documents.delete',['document_id' => $document_details->id] )); ?>" class="btn btn-danger btn-block">
                                <?php echo e(tr('delete')); ?>

                            </a>

                        <?php else: ?>
                        
                            <button class="btn btn-primary btn-block" disabled><?php echo e(tr('edit')); ?></button>

                            <button class="btn btn-warning btn-block" disabled><?php echo e(tr('delete')); ?></button>

                        <?php endif; ?>

                        <?php if($document_details->status == APPROVED): ?>

                            <a class="btn btn-warning btn-block" href="<?php echo e(route('admin.documents.status',['document_id' => $document_details->id] )); ?>" onclick="return confirm(&quot;<?php echo e($document_details->name); ?>-<?php echo e(tr('document_decline_confirmation' , $document_details->name)); ?>&quot;);">

                                <?php echo e(tr('decline')); ?>

                            </a>

                        <?php else: ?>

                            <a class="btn btn-success btn-block" href="<?php echo e(route('admin.documents.status',['document_id' => $document_details->id] )); ?>">
                                <?php echo e(tr('approve')); ?>

                            </a>
                               
                        <?php endif; ?>
                                             


                    </div>
                    <!-- Card content -->

                </div>
                <!-- Card -->

            </div>
            <!-- Card group -->

        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>