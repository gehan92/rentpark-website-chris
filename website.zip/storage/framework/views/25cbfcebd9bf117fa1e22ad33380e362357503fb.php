 

<?php $__env->startSection('title', tr('history')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.bookings.index')); ?>"><?php echo e(tr('bookings')); ?></a></li>
  
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('history')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12 grid-margin stretch-card">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('history')); ?></h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">
                    
                    <table id="order-listing" class="table">
                        
                        <thead>
                            <tr>
                                <th><?php echo e(tr('s_no')); ?></th>
                                <th><?php echo e(tr('user')); ?></th>
                                <th><?php echo e(tr('provider')); ?></th>
                                <th><?php echo e(tr('parking_space')); ?></th>
                                <th><?php echo e(tr('checkin')); ?>-<?php echo e(tr('checkout')); ?></th>
                                <th><?php echo e(tr('status')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>
                        
                        <tbody>
                         
                            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $booking_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($i+1); ?></td>

                                    <td>
                                        <?php if($booking_details->userDetails->name): ?>
                                            <a href="<?php echo e(route('admin.users.view',['user_id' => $booking_details->user_id ])); ?>"> <?php echo e($booking_details->userDetails->name); ?></a>
                                        <?php else: ?>
                                            <?php echo e(tr('user_not_avail')); ?>

                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('admin.providers.view',['provider_id' => $booking_details->provider_id])); ?>"><?php echo e($booking_details->providerDetails->name ?? tr('provider_not_avail')); ?></a>
                                    </td>

                                    <td> 
                                        <?php if(empty($booking_details->host_name)): ?>

                                            <?php echo e(tr('host_not_avail')); ?>

                                        
                                        <?php else: ?>
                                            <a href="<?php echo e(route('admin.spaces.view',['host_id' => $booking_details->host_id])); ?>"><?php echo e($booking_details->hostDetails->host_name ?? tr('host_not_avail')); ?> </a>
                                        <?php endif; ?>

                                    </td>

                                    <td>
                                        <?php echo e(common_date($booking_details->checkin, Auth::guard('admin')->user()->timezone, 'd M Y')); ?>

                                        -
                                        <?php echo e(common_date($booking_details->checkout, Auth::guard('admin')->user()->timezone, 'd M Y')); ?>


                                    </td>
                                  
                                    <td>                                    
                                        <span class="text-info"><?php echo e(booking_status( $booking_details->status)); ?></span>
                                    </td>
                                   
                                    <td>   
                                        <a class="btn btn-primary" href="<?php echo e(route('admin.bookings.view', ['booking_id' => $booking_details->id])); ?>"><i class="fa fa-eye"></i><?php echo e(tr('view')); ?></a>
                                        
                                    </td>

                                </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                 
                        </tbody>
                    
                    </table>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>