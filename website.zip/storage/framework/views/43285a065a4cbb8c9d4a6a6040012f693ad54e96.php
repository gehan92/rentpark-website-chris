 

<?php $__env->startSection('title', tr('bookings_payments')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a><?php echo e(tr('revenues')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('bookings_payments')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

	<div class="col-lg-12 grid-margin">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('bookings_payments')); ?></h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">

                	<table id="order-listing" class="table">
                        
                        <thead>

                            <tr>
								<th><?php echo e(tr('s_no')); ?></th>
                                <th><?php echo e(tr('booking_id')); ?></th>
								<th><?php echo e(tr('user')); ?></th>
								<th><?php echo e(tr('provider')); ?></th>
                                <th><?php echo e(tr('host')); ?></th>
								<th><?php echo e(tr('pay_via')); ?></th>
								<th><?php echo e(tr('total')); ?></th>
                                <th><?php echo e(tr('status')); ?></th>
								<th><?php echo e(tr('action')); ?></th>
                            </tr>

                        </thead>
                        
                        <tbody>

                            <?php if(count($booking_payments) > 0 ): ?>
                            
                                <?php $__currentLoopData = $booking_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $booking_payment_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($i+1); ?></td>

                                        <td>
                                            <a href="<?php echo e(route('admin.bookings.view', ['booking_id' => $booking_payment_details->booking_id])); ?>">#<?php echo e($booking_payment_details->booking_unique_id); ?>

                                            </a> 
                                        </td>
                                                                                
                                        <td> 
                                            <?php if(empty($booking_payment_details->user_name)): ?>

                                                <?php echo e(tr('user_not_avail')); ?>

                                            
                                            <?php else: ?>
                                                <a href="<?php echo e(route('admin.users.view',['user_id' => $booking_payment_details->user_id])); ?>"><?php echo e($booking_payment_details->user_name); ?></a>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if(empty($booking_payment_details->provider_name)): ?>

                                                <?php echo e(tr('provider_not_avail')); ?>

                                            
                                            <?php else: ?>
                                                <a href="<?php echo e(route('admin.providers.view',['provider_id' => $booking_payment_details->provider_id])); ?>"><?php echo e($booking_payment_details->provider_name); ?></a>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if(empty($booking_payment_details->host_name)): ?>

                                                <?php echo e(tr('host_not_avail')); ?>

                                            
                                            <?php else: ?>
                                                <a href="<?php echo e(route('admin.spaces.view',['host_id' => $booking_payment_details->host_id])); ?>"><?php echo e($booking_payment_details->host_name); ?></a>
                                            <?php endif; ?>
                                        </td>
                                        
                                        <td> 
                                            <?php echo e($booking_payment_details->payment_mode); ?>

                                        </td>

                                        <td>
                                            <?php echo e(formatted_amount($booking_payment_details->total)); ?>                   
                                        </td>

                                        <td>
                                            <?php if($booking_payment_details->status): ?>

                                                <div class="badge badge-success badge-fw"><?php echo e(tr('paid')); ?></div>
                                          
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <a class="btn btn-primary" href="<?php echo e(route('admin.bookings.view', ['booking_id' => $booking_payment_details->booking_id] )); ?>">
                                                <?php echo e(tr('view')); ?>

                                            </a> 
                                        </td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>

                                <tr>
                                    <td><?php echo e(tr('no_result_found')); ?></td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>	

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>