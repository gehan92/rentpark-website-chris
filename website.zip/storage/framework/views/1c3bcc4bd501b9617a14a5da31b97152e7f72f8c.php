 

<?php $__env->startSection('title', tr('providers')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.providers.index')); ?>"><?php echo e(tr('providers')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_providers')); ?></span>
    </li>
                      
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12 grid-margin stretch-card">

        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('providers')); ?>


                    <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.providers.create')); ?>">
                        <i class="fa fa-plus"></i> <?php echo e(tr('add_provider')); ?>

                    </a>
                </h4>

            </div>
        
            <div class="card-body">
                
                <div class="table-responsive">
                   
                    <table id="order-listing" class="table">
                    
                        <thead>
                            <tr>
                                <th><?php echo e(tr('s_no')); ?></th>
                                <th><?php echo e(tr('name')); ?></th>
                                <th><?php echo e(tr('email')); ?></th>
                                <th><?php echo e(tr('status')); ?></th>
                                <th><?php echo e(tr('verify')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>
                    
                        <tbody>
                         
                            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $provider_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                                <tr>

                                    <td><?php echo e($i+1); ?></td>
                                  
                                    <td>
                                        <a href="<?php echo e(route('admin.providers.view' , ['provider_id' => $provider_details->id])); ?>">    
                                            <?php echo e($provider_details->name); ?>

                                        </a>
                                        <?php if($provider_details->provider_type == NO): ?>    
                                            <i class="fa fa-times-circle  text-danger"></i>
                                        <?php elseif($provider_details->provider_type == YES): ?>
                                            <i class="fa fa-check-circle text-success"></i>
                                        <?php endif; ?>
                                       
                                    </td>

                                    <td> <?php echo e($provider_details->email); ?> </td>

                                    <td>

                                        <?php if($provider_details->status == PROVIDER_APPROVED): ?>
                                         
                                            <span class="badge badge-outline-success">
                                                <?php echo e(tr('approved')); ?> 
                                            </span>

                                        <?php else: ?>

                                            <span class="badge badge-outline-danger">
                                                <?php echo e(tr('declined')); ?> 
                                            </span>
                                                 
                                        <?php endif; ?>

                                    </td>
                                    
                                    <td>   

                                        <?php if($provider_details->is_verified == PROVIDER_EMAIL_VERIFIED): ?>                   
                                            
                                            <span class="badge badge-outline-success">
                                                <?php echo e(tr('verified')); ?> 
                                            </span>

                                        <?php else: ?>
                                            
                                            <a class="badge badge-outline-info"  href="<?php echo e(route('admin.providers.verify', ['provider_id' => $provider_details->id])); ?> "> <?php echo e(tr('verify')); ?> </a>

                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>                                    
                                        
                                        <div class="template-demo">

                                            <div class="dropdown">

                                                <button class="btn btn-outline-primary  dropdown-toggle btn-sm" type="button" id="dropdownMenuOutlineButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <?php echo e(tr('action')); ?>

                                                </button>

                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuOutlineButton1">

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.providers.view', ['provider_id' => $provider_details->id])); ?>">
                                                        <?php echo e(tr('view')); ?>

                                                    </a>
                                                      
                                                    <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                                                        
                                                        <a class="dropdown-item" href="<?php echo e(route('admin.providers.edit', ['provider_id' => $provider_details->id])); ?>"><?php echo e(tr('edit')); ?>

                                                        </a>
                                                                                                        
                                                        <a class="dropdown-item" onclick="return confirm(&quot;<?php echo e(tr('provider_delete_confirmation' , $provider_details->name)); ?>&quot;);" href="<?php echo e(route('admin.providers.delete', ['provider_id' => $provider_details->id])); ?>"><?php echo e(tr('delete')); ?>

                                                        </a>

                                                    <?php else: ?>

                                                        <a class="dropdown-item" href="javascript:;"><?php echo e(tr('edit')); ?>

                                                        </a>
                                                        
                                                        <a class="dropdown-item" href="javascript:;"><?php echo e(tr('delete')); ?>

                                                        </a>

                                                    <?php endif; ?>

                                                    <div class="dropdown-divider"></div>

                                                    <?php if($provider_details->is_verified == NO): ?> 
                                                        
                                                        <a class="dropdown-item" href="<?php echo e(route('admin.providers.verify', ['provider_id' => $provider_details->id])); ?> "><?php echo e(tr('verify')); ?> 
                                                        </a>

                                                    <?php endif; ?>
                                                    

                                                    <?php if($provider_details->status == APPROVED): ?>

                                                        <a class="dropdown-item" href="<?php echo e(route('admin.providers.status', ['provider_id' => $provider_details->id])); ?>" onclick="return confirm(&quot;<?php echo e($provider_details->name); ?> - <?php echo e(tr('provider_decline_confirmation')); ?>&quot;);" >
                                                            <?php echo e(tr('decline')); ?> 
                                                        </a>      

                                                    <?php else: ?>

                                                        <a class="dropdown-item" href="<?php echo e(route('admin.providers.status', ['provider_id' => $provider_details->id])); ?>">
                                                            <?php echo e(tr('approve')); ?>

                                                        </a>
                                                           
                                                    <?php endif; ?>

                                                    <div class="dropdown-divider"></div>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.providers.revenues', ['provider_id' => $provider_details->id])); ?>">
                                                        <?php echo e(tr('revenues')); ?>

                                                    </a>

                                                     <a class="dropdown-item" href="<?php echo e(route('admin.provider_subscriptions.plans' , ['provider_id' => $provider_details->id])); ?>" ><?php echo e(tr('plans')); ?></a>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.providers.documents.view', array('provider_id'=>$provider_details->id))); ?>">
                                                        <?php echo e(tr('documents')); ?>

                                                    </a>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.bookings.index', ['provider_id' => $provider_details->id])); ?>">
                                                        <?php echo e(tr('bookings')); ?> 
                                                    </a>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.reviews.providers', ['provider_id' => $provider_details->id])); ?>">
                                                        <?php echo e(tr('reviews')); ?> 
                                                    </a> 
                                                        
                                                </div>

                                            </div>

                                        </div>
                                   
                                    </td>
                                
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                 
                        </tbody>
  
                    </table>
  
                </div>
  
            </div>
  
        </div>
  
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>