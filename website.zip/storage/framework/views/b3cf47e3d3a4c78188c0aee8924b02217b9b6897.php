 

<?php $__env->startSection('title', tr('view_users')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(tr('users')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_users')); ?></span>
    </li> 
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12 grid-margin stretch-card">

        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('view_users')); ?>


                    <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.users.create')); ?>">
                        <i class="fa fa-plus"></i> <?php echo e(tr('add_user')); ?>

                    </a>
                </h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">
                
                    <table id="order-listing" class="table">
                       
                        <thead>
                       
                            <tr>
                                <th><?php echo e(tr('s_no')); ?></th>
                                <th><?php echo e(tr('name')); ?></th>
                                <th><?php echo e(tr('email')); ?></th>
                                <th><?php echo e(tr('status')); ?></th>
                                <th><?php echo e(tr('verify')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>
                       
                        </thead>
                      
                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                                <tr>
                                    <td><?php echo e($i+1); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('admin.users.view' , ['user_id' => $user_details->id])); ?>"> <?php echo e($user_details->name); ?>

                                        </a>
                                    </td>

                                    <td> <?php echo e($user_details->email); ?> </td>

                                    <td>

                                        <?php if($user_details->status == USER_APPROVED): ?>

                                            <span class="badge badge-outline-success"><?php echo e(tr('approved')); ?> </span>

                                        <?php else: ?>

                                            <span class="badge badge-outline-danger"><?php echo e(tr('declined')); ?> </span>

                                        <?php endif; ?>

                                    </td>

                                    <td>   

                                        <?php if($user_details->is_verified == USER_EMAIL_VERIFIED): ?> 

                                            <span class="badge badge-outline-success"><?php echo e(tr('verified')); ?> </span>

                                        <?php else: ?>

                                            <a class="badge badge-info" href="<?php echo e(route('admin.users.verify', ['user_id' => $user_details->id])); ?>"> 
                                                <?php echo e(tr('verify')); ?> 
                                            </a>

                                        <?php endif; ?>  
                                                                      
                                    </td>

                                    <td>     

                                        <div class="template-demo">

                                            <div class="dropdown">

                                                <button class="btn btn-outline-primary  dropdown-toggle" type="button" id="dropdownMenuOutlineButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <?php echo e(tr('action')); ?>

                                                </button>

                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuOutlineButton1">
                                                  
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.users.view', ['user_id' => $user_details->id])); ?>">
                                                        <?php echo e(tr('view')); ?>

                                                    </a>
                                                    
                                                    <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                                                        <a class="dropdown-item" href="<?php echo e(route('admin.users.edit', ['user_id' => $user_details->id])); ?>">
                                                            <?php echo e(tr('edit')); ?>

                                                        </a>
                                                        
                                                        <a class="dropdown-item" href="<?php echo e(route('admin.users.delete', ['user_id' => $user_details->id])); ?>" 
                                                        onclick="return confirm(&quot;<?php echo e(tr('user_delete_confirmation' , $user_details->name)); ?>&quot;);">
                                                            <?php echo e(tr('delete')); ?>

                                                        </a>
                                                    <?php else: ?>

                                                        <a class="dropdown-item" href="javascript:;"><?php echo e(tr('edit')); ?></a>
                                                      
                                                        <a class="dropdown-item" href="javascript:;"><?php echo e(tr('delete')); ?></a>                           
                                                    <?php endif; ?>

                                                    <div class="dropdown-divider"></div>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.users.view', ['user_id' => $user_details->id])); ?>#vehicle_details"> <?php echo e(tr('vehicle_details')); ?>

                                                    </a>
                                                    
                                                    <div class="dropdown-divider"></div>

                                                    <?php if($user_details->is_verified == USER_EMAIL_NOT_VERIFIED): ?> 

                                                        <a class="dropdown-item" href="<?php echo e(route('admin.users.verify', ['user_id' => $user_details->id])); ?>"> <?php echo e(tr('verify')); ?> 
                                                        </a>

                                                    <?php endif; ?> 

                                                    <?php if($user_details->status == USER_APPROVED): ?>

                                                        <a class="dropdown-item" href="<?php echo e(route('admin.users.status', ['user_id' => $user_details->id])); ?>" onclick="return confirm(&quot;<?php echo e($user_details->first_name); ?> - <?php echo e(tr('user_decline_confirmation')); ?>&quot;);" >
                                                            <?php echo e(tr('decline')); ?> 
                                                        </a>

                                                    <?php else: ?>
                                                        
                                                        <a class="dropdown-item" href="<?php echo e(route('admin.users.status', ['user_id' => $user_details->id])); ?>">
                                                            <?php echo e(tr('approve')); ?> 
                                                        </a>
                                                           
                                                    <?php endif; ?>

                                                    <div class="dropdown-divider"></div>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.bookings.index', ['user_id' => $user_details->id])); ?>">
                                                        <?php echo e(tr('bookings')); ?> 
                                                    </a> 

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.reviews.users', ['user_id' => $user_details->id])); ?>">
                                                        <?php echo e(tr('reviews')); ?> 
                                                    </a>  

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.wishlists.index', ['user_id' => $user_details->id])); ?>">
                                                      <?php echo e(tr('wishlist')); ?> 
                                                    </a>  

                                                </div>

                                            </div>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                 
                        </tbody>
                
                    </table>

                </div>

            </div>
        
        </div>
    
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>