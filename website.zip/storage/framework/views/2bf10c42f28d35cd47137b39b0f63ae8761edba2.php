 

<?php $__env->startSection('title', tr('view_providers')); ?> 

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.providers.index')); ?>"><?php echo e(tr('provider')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_providers')); ?></span>
    </li>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-md-12">

        <!-- Card group -->
        <div class="card-group">

            <!-- Card -->
            <div class="card mb-6">

                <!-- Card image -->
                <div class="view overlay">
                    <img class="card-img-top" src="<?php echo e($provider_details->picture); ?>">
                    <a href="#!">
                        <div class="mask rgba-white-slight"></div>
                    </a>
                </div>

                <!-- Card content -->
                <div class="card-body">

                    <div class="row"> 
                        <div class="col-md-6">
 
                            <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <a href="<?php echo e(route('admin.providers.edit', ['provider_id' => $provider_details->id])); ?>" class="btn btn-primary btn-block"><?php echo e(tr('edit')); ?></a>

                            <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.providers.delete', ['provider_id' => $provider_details->id])); ?>" onclick="return confirm(&quot;<?php echo e(tr('provider_delete_confirmation' , $provider_details->first_name)); ?>&quot;);" class="btn btn-danger btn-block"><?php echo e(tr('delete')); ?></a> 

                            <?php else: ?>

                                <a href="javascript:;" class="btn btn-primary btn-block"><?php echo e(tr('edit')); ?></a>

                                <a class="btn btn-danger btn-block" href="javascript:;"><?php echo e(tr('delete')); ?></a> 

                            <?php endif; ?> 

                            <?php if($provider_details->is_verified == NO): ?>  
                                    
                                <a class="btn btn-info btn-block" href="<?php echo e(route('admin.providers.verify', ['provider_id' => $provider_details->id])); ?> "><?php echo e(tr('verify')); ?> 
                                </a>

                            <?php endif; ?>

                            <?php if($provider_details->status == PROVIDER_APPROVED): ?>

                                <a class="btn btn-danger btn-block" onclick="return confirm(&quot;<?php echo e($provider_details->first_name); ?> - <?php echo e(tr('provider_decline_confirmation')); ?>&quot;);" href="<?php echo e(route('admin.providers.status', ['provider_id' => $provider_details->id])); ?>"><?php echo e(tr('decline')); ?></a> 

                            <?php else: ?>

                                <a class="btn btn-success btn-block" href="<?php echo e(route('admin.providers.status', ['provider_id' => $provider_details->id])); ?>"><?php echo e(tr('approve')); ?></a> 

                            <?php endif; ?>
                            
                            <a href="<?php echo e(route('admin.spaces.index',['provider_id' => $provider_details->id])); ?>" class="btn btn-info btn-block"><?php echo e(tr('parking_space')); ?></a>

                        </div>

                        <div class="col-md-6">
                            
                            <a class="btn btn-success btn-block" href="<?php echo e(route('admin.provider_subscriptions.plans' , ['provider_id' => $provider_details->id])); ?>" ><?php echo e(tr('plans')); ?></a>

                            <a class="btn btn-info btn-block" href="<?php echo e(route('admin.bookings.index', ['provider_id' => $provider_details->id])); ?>">
                                <?php echo e(tr('bookings')); ?> 
                            </a>

                            <a class="btn btn-warning btn-block" href="<?php echo e(route('admin.reviews.providers', ['provider_id' => $provider_details->id])); ?>">
                                <?php echo e(tr('reviews')); ?> 
                            </a> 

                        </div>

                    </div>
                    <hr>

                    <div class="row">
                        <!-- Title -->
                        <?php if($provider_details->description): ?>
                            <h4 class="card-title"><?php echo e(tr('description')); ?></h4>
                            <!-- Text -->
                            <p class="card-text"><?php echo e($provider_details->description); ?></p>
                        <?php endif; ?>
                    </div>

                </div>
                <!-- Card content -->   

            </div>
            <!-- Card -->

            <!-- Card -->
            <div class="card mb-6">

                <!-- Card content -->
                <div class="card-body">

                    <div class="template-demo">

                        <table class="table mb-0">

                            <tbody>
                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('name')); ?></b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->name); ?></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('status')); ?></b></td>

                                    <td class="pr-0  text-right">
                                        <?php if($provider_details->status == APPROVED): ?>

                                            <span class="badge badge-success badge-md text-uppercase"><?php echo e(tr('approved')); ?></span> 

                                        <?php else: ?>

                                            <span class="badge badge-danger badge-md text-uppercase"><?php echo e(tr('pending')); ?></span>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('email')); ?></b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->email); ?></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('mobile')); ?></b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->mobile); ?></div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('device_type')); ?></b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->device_type); ?></div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('payment_mode')); ?> </b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->payment_mode); ?></div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b><?php echo e(tr('timezone')); ?></b></td>
                                    <td class="pr-0  text-right">
                                        <?php echo e($provider_details->timezone); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('account_name')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e($provider_billing_info->account_name ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('paypal_email')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e($provider_billing_info->paypal_email ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('account_no')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e($provider_billing_info->account_no ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('route_no')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e($provider_billing_info->route_no ?? ''); ?> </div>
                                    </td>
                                </tr>

                            </tbody>

                        </table>

                    </div>
                    <!-- </div> -->

                </div>
                <!-- Card content -->

            </div>

            <!-- Card -->

            <!-- Card -->
            <div class="card mb-6">

                <!-- Card content -->
                <div class="card-body">

                    <table class="table mb-0">
                        <tbody>
                             <tr>
                                <td class="pl-0"><b><?php echo e(tr('is_email_verified')); ?></b></td>

                                    <td class="pr-0  text-right">
                                        <?php if($provider_details->is_verified == PROVIDER_EMAIL_NOT_VERIFIED): ?>

                                        <span class="card-text label label-rouded label-menu label-danger"><?php echo e(tr('no')); ?></span> 

                                        <?php else: ?>

                                        <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('yes')); ?></span> 

                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <tr>                                
                                    <td class="pl-0"><b><?php echo e(tr('push_notification')); ?></b></td>

                                    <td class="pr-0  text-right ">

                                        <?php if($provider_details->push_notification_status): ?>

                                        <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('on')); ?></span> 

                                        <?php else: ?>

                                        <span class="card-text badge badge-danger badge-md text-uppercase"><?php echo e(tr('off')); ?></span> 

                                        <?php endif; ?>

                                    </td>
                                </tr>   

                                <tr>                                
                                    <td class="pl-0"><b><?php echo e(tr('email_notification')); ?></b></td>

                                     <td class="pr-0 text-right">
                                        <?php if($provider_details->email_notification_status): ?>

                                        <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('on')); ?></span> 

                                        <?php else: ?>

                                        <span class="card-text badge badge-danger badge-md text-uppercase"><?php echo e(tr('off')); ?></span> 

                                        <?php endif; ?>
                                    </td>
                                </tr>
                             
                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('work')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e($provider_details->work); ?> </div>
                                    </td>
                                </tr> 

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('school')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e($provider_details->school); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('full_address')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e($provider_details->full_address); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('languages')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e($provider_details->languages); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('login_by')); ?></b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->login_by); ?></div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0">
                                        <b><?php echo e(tr('register_type')); ?> </b></td>
                                    <td class="pr-0 text-right">
                                        <div><?php echo e($provider_details->register_type); ?></div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('created_at')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e(common_date($provider_details->created_at)); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('updated_at')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e(common_date($provider_details->updated_at)); ?> </div>
                                    </td>
                                </tr>

                            </tbody>

                        </table>

                    </div>
                    <!-- </div> -->

                </div>
                <!-- Card content -->

            </div>

            <!-- Card -->

        </div>
        <!-- Card group -->

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>