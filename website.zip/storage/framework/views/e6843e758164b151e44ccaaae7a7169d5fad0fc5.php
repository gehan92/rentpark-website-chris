 

<?php $__env->startSection('title', tr('view_user')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(tr('users')); ?></a>
    </li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_user')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>
    
    <div class="row">

        <div class="col-md-12">

            <!-- Card group -->
            <div class="card-group">

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card image -->
                    <div class="view overlay">

                        <img class="card-img-top" src="<?php echo e($user_details->picture); ?>">
                        <a href="#!">
                            <div class="mask rgba-white-slight"></div>
                        </a>
                    </div>

                    <div class="card-body">

                        <div class="row">

                            <div class="col-md-6">

                                <?php if(Setting::get('is_demo_control_enabled') == YES): ?>

                                    <a href="javascript:;" class="btn btn-primary btn-block"><?php echo e(tr('edit')); ?></a>

                                    <a href="javascript:;" class="btn btn-danger btn-block"><?php echo e(tr('delete')); ?></a>

                                <?php else: ?>

                                    <a class="btn btn-primary btn-block" href="<?php echo e(route('admin.users.edit', ['user_id' => $user_details->id])); ?>"><?php echo e(tr('edit')); ?></a>

                                    <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.users.delete', ['user_id' => $user_details->id])); ?>" onclick="return confirm(&quot;<?php echo e(tr('user_delete_confirmation' , $user_details->name)); ?>&quot;);"><?php echo e(tr('delete')); ?></a>

                                <?php endif; ?>

                                <?php if($user_details->status == USER_APPROVED): ?>

                                    <a class="btn btn-danger btn-block" href="<?php echo e(route('admin.users.status', ['user_id' => $user_details->id])); ?>" onclick="return confirm(&quot;<?php echo e($user_details->first_name); ?> - <?php echo e(tr('user_decline_confirmation')); ?>&quot;);" >
                                        <?php echo e(tr('decline')); ?> 
                                    </a>

                                <?php else: ?>
                                    
                                    <a class="btn btn-success btn-block" href="<?php echo e(route('admin.users.status', ['user_id' => $user_details->id])); ?>">
                                        <?php echo e(tr('approve')); ?> 
                                    </a>
                                       
                                <?php endif; ?>

                            </div>
                            
                            <div class="col-md-6">

                                <?php if($user_details->is_verified == USER_EMAIL_NOT_VERIFIED): ?> 

                                    <a class="btn btn-primary btn-block" href="<?php echo e(route('admin.users.verify', ['user_id' => $user_details->id])); ?>"> <?php echo e(tr('verify')); ?> 
                                    </a>   

                                <?php endif; ?> 

                                <a class="btn btn-info btn-block" href="<?php echo e(route('admin.bookings.index', ['user_id' => $user_details->id])); ?>">
                                  <?php echo e(tr('bookings')); ?> 
                                </a> 

                                <a class="btn btn-warning btn-block" href="<?php echo e(route('admin.reviews.users', ['user_id' => $user_details->id])); ?>">
                                  <?php echo e(tr('reviews')); ?> 
                                </a> 

                                <a class="btn btn-warning btn-block" href="<?php echo e(route('admin.wishlists.index', ['user_id' => $user_details->id])); ?>">
                                  <?php echo e(tr('wishlist')); ?> 
                                </a>  

                            </div>
                                
                        </div>

                        <hr>

                        <div class="row">
                            <?php if($user_details->description): ?>
                                <h5 class="col-md-12"><?php echo e(tr('description')); ?></h5>

                                <p class="col-md-12 text-muted"><?php echo e($user_details->description); ?></p>
                            <?php endif; ?>
                        </div>


                    </div>
                
                </div>
                <!-- Card -->

                <!-- Card -->
                <div class="card mb-4">

                    <!-- Card content -->
                    <div class="card-body">

                        <div class="template-demo">

                            <table class="table mb-0">

                              <tbody>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('name')); ?></b></td>
                                    <td class="pr-0 text-right"><div ><?php echo e($user_details->name); ?></div></td>
                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('email')); ?></b></td>
                                    <td class="pr-0 text-right"><div ><?php echo e($user_details->email); ?></div></td>
                                </tr>
                                

                                <tr>

                                  <td class="pl-0"> <b><?php echo e(tr('status')); ?></b></td>

                                  <td class="pr-0 text-right">

                                        <?php if($user_details->status == USER_PENDING): ?>

                                            <span class="card-text badge badge-danger badge-md text-uppercase"><?php echo e(tr('pending')); ?></span>

                                        <?php elseif($user_details->status == USER_APPROVED): ?>

                                            <span class="card-text  badge badge-success badge-md text-uppercase"><?php echo e(tr('approved')); ?></span>

                                        <?php else: ?>

                                            <span class="card-text label label-rouded label-menu label-danger"><?php echo e(tr('declined')); ?></span>

                                        <?php endif; ?>

                                  </td>

                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('device_type')); ?></b></td>
                                    <td class="pr-0 text-right"><div ><?php echo e($user_details->device_type); ?></div></td>
                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('login_by')); ?></b></td>
                                    <td class="pr-0 text-right"><div><?php echo e($user_details->login_by); ?></div></td>
                                </tr>

                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('register_type')); ?> </b></td>
                                    <td class="pr-0 text-right"><div><?php echo e($user_details->register_type); ?></div></td>
                                </tr>


                                <tr>
                                    <td class="pl-0"> <b><?php echo e(tr('timezone')); ?></b></td>
                                    <td class="pr-0 text-right"><div><?php echo e($user_details->timezone); ?></div></td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b><?php echo e(tr('created_at')); ?></b></td>
                                    <td class="pr-0 text-right"><div><?php echo e(common_date($user_details->created_at)); ?></div></td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b><?php echo e(tr('updated_at')); ?></b></td>
                                    <td class="pr-0 text-right"><div><?php echo e(common_date($user_details->updated_at)); ?></div></td>
                                </tr>

                              </tbody>

                            </table>

                        </div>
                        <!-- </div> -->

                    </div>
                    <!-- Card content -->

                </div>

                <div class="card mb-4">
                    <!-- Card content -->
                    <div class="card-body">

                        <div class="template-demo">

                            <table class="table mb-0">

                              <tbody>


                                <tr>
                                    <td class="pl-0"><b><?php echo e(tr('payment_mode')); ?> </b></td>
                                    <td class="pr-0 text-right"><div ><?php echo e($user_details->payment_mode); ?></div></td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('account_name')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div> <?php echo e($user_billing_info->account_name ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('account_no')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e($user_billing_info->account_no ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('paypal_email')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e($user_billing_info->paypal_email ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="pl-0"> <b> <?php echo e(tr('route_no')); ?> </b> </td>
                                    <td class="pr-0  text-right">
                                        <div><?php echo e($user_billing_info->route_no ?? ''); ?> </div>
                                    </td>
                                </tr>

                                <tr> 

                                    <td class="pl-0"><b><?php echo e(tr('is_email_verified')); ?></b></td>
                                    
                                    <td class="pr-0 text-right">

                                        <?php if($user_details->is_verified == USER_EMAIL_NOT_VERIFIED): ?>

                                            <span class="card-text label label-rouded label-menu label-danger"><?php echo e(tr('no')); ?></span>

                                        <?php else: ?>

                                            <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('yes')); ?></span>

                                        <?php endif; ?>
                                    </td>

                                </tr>

                                <tr> 

                                    <td class="pl-0"><b><?php echo e(tr('push_notification')); ?></b></td>
                                    
                                    <td class="pr-0 text-right">

                                        <?php if($user_details->push_notification_status): ?>

                                            <span class="card-text label label-rouded label-menu label-danger"><?php echo e(tr('on')); ?></span>

                                        <?php else: ?>

                                            <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('off')); ?></span>

                                        <?php endif; ?>
                                    </td>

                                </tr>

                                <tr> 

                                    <td class="pl-0"><b><?php echo e(tr('email_notification')); ?></b></td>
                                    
                                    <td class="pr-0 text-right">

                                        <?php if($user_details->email_notification_status): ?>

                                            <span class="card-text label label-rouded label-menu label-danger"><?php echo e(tr('on')); ?></span>

                                        <?php else: ?>

                                            <span class="card-text badge badge-success badge-md text-uppercase"><?php echo e(tr('off')); ?></span>

                                        <?php endif; ?>
                                    </td>

                                </tr>

                              

                              </tbody>

                            </table>

                        </div>
                        <!-- </div> -->

                    </div>
                    <!-- Card content -->
                </div>

                <!-- Card -->

            </div>
            <!-- Card group -->

        </div>

    </div>
    
    <div class="row" id="vehicle_details">

        <div class="col-lg-12 grid-margin stretch-card">
            
            <div class="card">

                <div class="card-header">

                    <h4 class=""><?php echo e(tr('vehicle_details')); ?>

                    
                        <a class="btn btn-success pull-right" href="<?php echo e(route('admin.vehicle_details.create', ['user_id' => $user_details->id])); ?>"> <?php echo e(tr('add_vehicle')); ?>

                        </a>

                    </h4>

                </div>

                <div class="card-body">

                    <div class="table-responsive">
                    
                        <table id="order-listing" class="table">
                           
                            <thead>
                               
                                <tr>
                                    <th><?php echo e(tr('vehicle_number')); ?></th>
                                    <th><?php echo e(tr('vehicle_type')); ?></th>
                                    <th><?php echo e(tr('vehicle_brand')); ?></th>
                                    <th><?php echo e(tr('vehicle_model')); ?></th>
                                    <th><?php echo e(tr('action')); ?></th>
                                </tr>

                            </thead>
                           
                            <tbody>

                                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $vehicle_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                    <tr>
                                        
                                        <td><?php echo e($vehicle_details->vehicle_number); ?> </td>

                                        <td><?php echo e($vehicle_details->vehicle_type); ?> </td>

                                        <td><?php echo e($vehicle_details->vehicle_brand); ?> </td>

                                        <td><?php echo e($vehicle_details->vehicle_model); ?> </td>

                                        <td>
                                           
                                            <a href="<?php echo e(route('admin.vehicle_details.edit', ['vehicle_id' => $vehicle_details->id] )); ?>" class="btn btn-primary" title="<?php echo e(tr('edit')); ?>"><i class="mdi mdi-border-color"></i><?php echo e(tr('edit')); ?></a>
                                            
                                            <a href="<?php echo e(route('admin.vehicle_details.delete', ['vehicle_id' => $vehicle_details->id] )); ?>" class="btn btn-danger" title="<?php echo e(tr('delete')); ?>"><i class="mdi mdi-delete"></i><?php echo e(tr('delete')); ?></a>
                                       
                                        </td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                     
                            </tbody>

                        </table>

                    </div>

                </div>

            </div>
        
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>