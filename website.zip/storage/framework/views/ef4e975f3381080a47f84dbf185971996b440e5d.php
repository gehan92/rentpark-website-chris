 

<?php $__env->startSection('title', tr('payments')); ?>

<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item active" aria-current="page">
    <span><?php echo e(tr('view_provider_subscription_payment')); ?></span>
</li>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

<div class="col-lg-12 grid-margin stretch-card">
    
    <div class="card">

        <div class="card-header bg-card-header ">
            <h4 class=""><?php echo e(tr('view_provider_subscription_payment')); ?> </h4>
        </div>

        <div class="card-body">

            <div class="row">

                <div class=" col-sm-6 table-responsive">
                    
                    <h6 class="card-title"><?php echo e(tr('details')); ?></h6>

                    <table class="table table-bordered table-striped tab-content">
                       
                        <tbody>
                      
                            <tr>
                                <td><?php echo e(tr('provider')); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('admin.providers.view' , ['provider_id' => $provider_subscription_payment->provider_id ])); ?>">
                                    <?php echo e($provider_subscription_payment->providerDetails->name ?? tr('provider_not_avail')); ?>

                                    </a>
                                </td>
                            </tr> 
                            <tr>
                                <td><?php echo e(tr('provider_subscription')); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('admin.provider_subscriptions.view' ,['provider_subscription_id' => $provider_subscription_payment->provider_subscription_id])); ?>"><?php echo e($provider_subscription_payment->providerSubscriptionDetails->title ?? tr('provider_subscription_not_avail')); ?></a>
                                </td>
                            </tr> 
                            <tr>
                                <td><?php echo e(tr('payment_id')); ?></td>
                                <td><?php echo e($provider_subscription_payment->payment_id); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(tr('paid_at')); ?> </td>
                                <td><?php echo e(common_date($provider_subscription_payment->updated_at, Auth::guard('admin')->user()->timezone)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(tr('plan')); ?></td>
                                <td><?php echo e(plan_text( $provider_subscription_payment->providerSubscriptionDetails->plan ?? '0',  $provider_subscription_payment->providerSubscriptionDetails->plan_type ?? '')); ?></td>
                            </tr>

                            <tr>
                                <td><?php echo e(tr('is_current_subscription')); ?></td>
                                <td>
                                    <?php if( $provider_subscription_payment->is_current_subscription ): ?> 
                                        <span class="badge badge-success badge-fw"><?php echo e(tr('yes')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-danger badge-fw"><?php echo e(tr('no')); ?></span>

                                    <?php endif; ?>
                                </td>
                            </tr>


                            <tr>
                                <td><?php echo e(tr('expiry_at')); ?></td>
                                <td><?php echo e(common_date($provider_subscription_payment->expiry_date, Auth::guard('admin')->user()->timezone)); ?></td>
                            </tr>

                            <tr>
                                <td><?php echo e(tr('subscription_amount')); ?></td>
                                <td><?php echo e(formatted_amount($provider_subscription_payment->subscription_amount)); ?></td>
                            </tr>

                            <tr>
                                <td><?php echo e(tr('paid_amount')); ?></td>
                                <td><?php echo e(formatted_amount($provider_subscription_payment->paid_amount)); ?></td>
                            </tr>

                            <tr>
                                <td><?php echo e(tr('status')); ?></td>
                                <td>
                                    <?php if($provider_subscription_payment->status ): ?> 
                                           
                                        <span class="badge badge-success badge-fw"><?php echo e(tr('paid')); ?></span>

                                    <?php else: ?>
                                           
                                        <span class="badge badge-danger badge-fw"><?php echo e(tr('not_paid')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td><?php echo e(tr('is_cancelled')); ?></td>
                                <td>
                                    <?php if( $provider_subscription_payment->is_cancelled ): ?> 
                                        <span class="badge badge-success badge-fw"><?php echo e(tr('yes')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-danger badge-fw"><?php echo e(tr('no')); ?></span>

                                    <?php endif; ?>
                                </td>
                            </tr>

                            <?php if( $provider_subscription_payment->is_cancelled == YES): ?>
                                <tr>
                                    <td><?php echo e(tr('reason')); ?></td>

                                    <td>
                                        <?php echo e($provider_subscription_payment->cancelled_reason); ?>                                        
                                    </td>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <td><?php echo e(tr('subscribed_by')); ?> </td>
                                <td>
                                    <?php echo e($provider_subscription_payment->subscribed_by ?? tr('no_subscriber_avail')); ?>

                                    </a>
                                </td>
                            </tr> 

                            <tr>
                                <td><?php echo e(tr('created_at')); ?></td>
                                <td><?php echo e(common_date($provider_subscription_payment->created_at, Auth::guard('admin')->user()->timezone)); ?></td>
                            </tr>

                            <tr>
                                <td><?php echo e(tr('updated_at')); ?></td>
                                <td><?php echo e(common_date($provider_subscription_payment->updated_at, Auth::guard('admin')->user()->timezone)); ?></td>
                            </tr>


                        </tbody>

                    </table>

                </div>


                <div class=" col-sm-6 table-responsive">
                    
                    <h6 class="card-title"><?php echo e(tr('picture')); ?></h6>

                    <img src="<?php echo e($provider_subscription_payment->providerDetails->picture); ?>" class="picture">                    
                    
                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>