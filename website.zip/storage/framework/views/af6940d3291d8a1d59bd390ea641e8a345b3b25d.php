 

<?php $__env->startSection('title', tr('settings')); ?>

<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item active" aria-current="page">

    <span><?php echo e(tr('settings')); ?></span>
</li>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('styles'); ?>

<style>
    
/*  rental tab */
div.rental-tab-container{
    z-index: 10;
    background-color: #ffffff;
    padding: 0 !important;
    border-radius: 4px;
    -moz-border-radius: 4px;
    border:1px solid #ddd;
    margin-top: 20px;
    margin-left: 50px;
    -webkit-box-shadow: 0 6px 12px rgba(3, 169, 243, 0.5);
    box-shadow: 0 6px 12px rgba(3, 169, 243, 0.5);
    -moz-box-shadow: 0 6px 12px rgba(3, 169, 243, 0.5);
    background-clip: padding-box;
    opacity: 0.97;
    filter: alpha(opacity=97);
}
div.rental-tab-menu{
    padding-right: 0;
    padding-left: 0;
    padding-bottom: 0;
}
div.rental-tab-menu div.list-group{
    margin-bottom: 0;
}
div.rental-tab-menu div.list-group>a{
    margin-bottom: 0;
}
div.rental-tab-menu div.list-group>a .glyphicon,
div.rental-tab-menu div.list-group>a .fa {
    color: #00B632;
}
div.rental-tab-menu div.list-group>a:first-child{
    border-top-right-radius: 0;
    -moz-border-top-right-radius: 0;
}
div.rental-tab-menu div.list-group>a:last-child{
    border-bottom-right-radius: 0;
    -moz-border-bottom-right-radius: 0;
}
div.rental-tab-menu div.list-group>a.active,
div.rental-tab-menu div.list-group>a.active .glyphicon,
div.rental-tab-menu div.list-group>a.active .fa{
    background-color: #00B632;
    /*background-image: #00B632;*/
    color: #ffffff;
    border: 2px dashed;
}
div.rental-tab-menu div.list-group>a.active:after{
    content: '';
    position: absolute;
    left: 100%;
    top: 50%;
    margin-top: -13px;
    border-left: 0;
    border-bottom: 13px solid transparent;
    border-top: 13px solid transparent;
    border-left: 10px solid #00B632;
}

div.rental-tab-content{
    background-color: #ffffff;
    /* border: 1px solid #eeeeee; */
    padding-left: 20px;
    padding-top: 10px;
}

.box-body {
    padding: 0px;
}

div.rental-tab div.rental-tab-content:not(.active){
  display: none;
}

.sub-title {
    width: fit-content;
    color: #2c648c;
    font-size: 18px;
    /*border-bottom: 2px dashed #285a86;*/
    padding-bottom: 5px;
}

hr {
    margin-top: 15px;
    margin-bottom: 15px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    
     <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 rental-tab-menu">
        
        <div class="list-group">
            <a href="#" class="list-group-item active text-left text-uppercase">
                <!-- <i class="fa fa-globe" style="display: inline-block;"></i> -->
                <!-- <br/> -->
                <?php echo e(tr('site_settings')); ?>

            </a>
           
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('booking_settings')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('payment_settings')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('email_settings')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('social_settings')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('social_login')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('notification_settings')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('apps_settings')); ?>

            </a>
            <a href="#" class="list-group-item text-left text-uppercase">
                <?php echo e(tr('other_settings')); ?>

            </a>

        </div>

    </div>
    
    <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 rental-tab">
        
        <!-- Site section -->            
        <div class="rental-tab-content active">

           <form id="site_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="row">

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('site_settings')); ?></b></h5>

                            <hr>

                        </div>

                        <div class="col-md-6">

                            <div class="form-group">
                                <label for="site_name"><?php echo e(tr('site_name')); ?> *</label>
                                <input type="text" class="form-control" id="site_name" name="site_name" placeholder="Enter <?php echo e(tr('site_name')); ?>" value="<?php echo e(Setting::get('site_name')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="site_logo"><?php echo e(tr('site_logo')); ?> *</label>
                                <p class="txt-warning"><?php echo e(tr('png_image_note')); ?></p>
                                <input type="file" class="form-control" id="site_logo" name="site_logo" accept="image/png" placeholder="<?php echo e(tr('site_logo')); ?>">
                            </div>
                            
                            <?php if(Setting::get('site_logo')): ?>

                                <img class="img img-thumbnail m-b-20" style="width: 40%" src="<?php echo e(Setting::get('site_logo')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>"> 

                            <?php endif; ?>

                        </div>

                        <div class="col-lg-6">

                            <div class="form-group">

                                <label for="frontend_url"><?php echo e(tr('frontend_url')); ?> *</label>

                                <input type="text" class="form-control" id="frontend_url" name="frontend_url" placeholder="<?php echo e(tr('frontend_url')); ?>" value="<?php echo e(Setting::get('frontend_url')); ?>">

                            </div>

                            <div class="form-group">

                                <label for="site_icon"><?php echo e(tr('site_icon')); ?> *</label>

                                <p class="txt-warning"><?php echo e(tr('png_image_note')); ?></p>

                                <input type="file" class="form-control" id="site_icon" name="site_icon" accept="image/png" placeholder="<?php echo e(tr('site_icon')); ?>">

                            </div>

                            <?php if(Setting::get('site_icon')): ?>

                                <img class="img img-thumbnail m-b-20" style="width: 20%" src="<?php echo e(Setting::get('site_icon')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>"> 

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

                <!-- /.box-body -->

                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
                </div>
            
            </form>
            <br>
        </div>

        <!-- Booking settings -->
        <div class="rental-tab-content">
            
            <form id="site_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST" enctype="multipart/form-data" class="forms-sample">
                
                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="row">

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('booking_settings')); ?></b></h5>

                            <hr>

                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">

                                <label for="per_base_price"><?php echo e(tr('per_base_price')); ?></label>

                                <p class="text-muted">Note: <?php echo e(tr('base_price_note')); ?></p>

                                <input type="number" class="form-control" id="per_base_price" name="per_base_price" placeholder="Enter <?php echo e(tr('base_price')); ?>" value="<?php echo e(old('per_base_price') ?: Setting::get('per_base_price')); ?>" min="0">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="google_api_key"><?php echo e(tr('google_api_key')); ?></label>
                                <p class="text-muted">Note: </p>
                                <input type="text" class="form-control" id="google_api_key" name="google_api_key" placeholder="Enter <?php echo e(tr('google_api_key')); ?>" value="<?php echo e(old('google_api_key') ?: Setting::get('google_api_key')); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="socket_url"><?php echo e(tr('socket_url')); ?></label>

                                <input type="text" class="form-control" id="socket_url" name="chat_socket_url" placeholder="Enter <?php echo e(tr('socket_url')); ?>" value="<?php echo e(old('chat_socket_url') ?: Setting::get('chat_socket_url')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">

                            <div class="form-group">
                                <label for="tax_percentage"><?php echo e(tr('tax_percentage')); ?></label>

                                <input type="number" class="form-control" id="tax_percentage" name="tax_percentage" placeholder="Enter <?php echo e(tr('tax_percentage')); ?>" value="<?php echo e(old('tax_percentage') ?: Setting::get('tax_percentage')); ?>"  min="0">
                            </div>

                        </div>

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('revenue_settings')); ?></b></h5>

                            <hr>

                        </div>
                        <div class="col-lg-6">

                            <div class="form-group">

                                <label for="request_admin_commission"><?php echo e(tr('request_admin_commission')); ?></label>

                                <input type="number" class="form-control" name="booking_admin_commission" placeholder="Enter <?php echo e(tr('request_admin_commission')); ?>" value="<?php echo e(old('booking_admin_commission') ?: Setting::get('booking_admin_commission')); ?>">
                            </div>
                        </div>
                        
                        <div class="clearfix"></div>

                    </div>

                </div>

                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
                </div>
            </form>
            <br>
        </div>

        <!-- Payment settings -->
        <div class="rental-tab-content">
            
            <form id="site_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST" enctype="multipart/form-data" class="forms-sample">
         
            <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="row">

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase"  style="color: #f30660;"><b><?php echo e(tr('payment_settings')); ?></b></h5>

                            <hr>

                        </div>
                        <div class="col-md-12">

                            <h5 class="sub-title"><?php echo e(tr('stripe_settings')); ?></h5>

                        </div>

                         <div class="col-lg-6">
                             <div class="form-group">

                                <label for="stripe_publishable_key"><?php echo e(tr('stripe_publishable_key')); ?> *</label>

                                <input type="text" class="form-control" id="stripe_publishable_key" name="stripe_publishable_key" placeholder="Enter <?php echo e(tr('stripe_publishable_key')); ?>" value="<?php echo e(old('stripe_publishable_key') ?: Setting::get('stripe_publishable_key')); ?>">

                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="stripe_secret_key"><?php echo e(tr('stripe_secret_key')); ?> *</label>

                                <input type="text" class="form-control" id="stripe_secret_key" name="stripe_secret_key" placeholder="Enter <?php echo e(tr('stripe_secret_key')); ?>" value="<?php echo e(old('stripe_secret_key') ?: Setting::get('stripe_secret_key')); ?>">
                            </div>
                        </div>
                         <div class="col-lg-6">
                           <label for="stripe_secret_key"><?php echo e(tr('stripe_mode')); ?> *</label>

                                <div class="clearfix"></div>

                                <div class="radio radio-aqua" style="display: inline-block;">

                                    <input id="stripe_live" name="stripe_mode" type="radio" value="<?php echo e(STRIPE_MODE_LIVE); ?>" <?php if(Setting::get('stripe_mode') == STRIPE_MODE_LIVE ): ?> checked="checked" <?php endif; ?>>

                                    <label for="stripe_live">
                                        <?php echo e(tr('live')); ?>

                                    </label>

                                </div>

                                <div class="radio radio-yellow" style="display: inline-block;">
                                    <input id="stripe_sandbox" name="stripe_mode" type="radio" value="<?php echo e(STRIPE_MODE_SANDBOX); ?>" <?php if(Setting::get( 'stripe_mode') == STRIPE_MODE_SANDBOX): ?> checked="checked" <?php endif; ?>>
                                    <label for="stripe_sandbox">
                                        <?php echo e(tr('sandbox')); ?>

                                    </label>
                                </div>
                        </div>

                    </div>

                </div>

                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
       
                </div>
       
            </form>
       
            <br>
       
        </div>

        <!-- Email settings -->
        <div class="rental-tab-content">
            <form id="site_settings_save" action="<?php echo e(route('admin.env-settings.save')); ?>" method="POST">

            <?php echo csrf_field(); ?>
        
                <div class="box-body">

                    <div class="row">

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('email_settings')); ?></b></h5>

                            <hr>

                        </div>

                        <div class="col-md-6">

                            <div class="form-group">
                                    <label for="MAIL_DRIVER"><?php echo e(tr('MAIL_DRIVER')); ?> *</label>
                                    <p class="text-muted"><?php echo e(tr('mail_driver_note')); ?></p>
                                    <input type="text" class="form-control" id="MAIL_DRIVER" name="MAIL_DRIVER" placeholder="Enter <?php echo e(tr('MAIL_DRIVER')); ?>" value="<?php echo e(old('MAIL_DRIVER') ?: $env_values['MAIL_DRIVER']); ?>">
                            </div>

                            <div class="form-group">
                                <label for="MAIL_HOST"><?php echo e(tr('MAIL_HOST')); ?> *</label>
                                <p class="text-muted"><?php echo e(tr('mail_host_note')); ?></p>

                                <input type="text" class="form-control" id="MAIL_HOST" name="MAIL_HOST" placeholder="Enter <?php echo e(tr('MAIL_HOST')); ?>" value="<?php echo e(old('MAIL_HOST') ?: $env_values['MAIL_HOST']); ?>">
                            </div>

                            <div class="form-group">
                                <label for="MAIL_FROM_ADDRESS"><?php echo e(tr('MAIL_FROM_ADDRESS')); ?> *</label>

                                <p class="text-muted"><?php echo e(tr('MAIL_FROM_ADDRESS_note')); ?></p>

                                <input type="text" class="form-control" id="MAIL_FROM_ADDRESS" name="MAIL_FROM_ADDRESS" placeholder="Enter <?php echo e(tr('MAIL_FROM_ADDRESS')); ?>" value="<?php echo e(old('MAIL_FROM_ADDRESS') ?: $env_values['MAIL_FROM_ADDRESS']); ?>">
                            </div>

                            <div class="form-group">
                                <label for="MAIL_PORT"><?php echo e(tr('MAIL_PORT')); ?> *</label>

                                <p class="text-muted"><?php echo e(tr('mail_port_note')); ?></p>

                                <input type="text" class="form-control" id="MAIL_PORT" name="MAIL_PORT" placeholder="Enter <?php echo e(tr('MAIL_PORT')); ?>" value="<?php echo e(old('MAIL_PORT') ?: $env_values['MAIL_PORT']); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">

                            <div class="form-group">
                                <label for="MAIL_USERNAME"><?php echo e(tr('MAIL_USERNAME')); ?> *</label>

                                <p class="text-muted"><?php echo e(tr('mail_username_note')); ?></p>

                                <input type="text" class="form-control" id="MAIL_USERNAME" name="MAIL_USERNAME" placeholder="Enter <?php echo e(tr('MAIL_USERNAME')); ?>" value="<?php echo e(old('MAIL_USERNAME') ?: $env_values['MAIL_USERNAME']); ?>">
                            </div>

                            <div class="form-group">

                                <label for="MAIL_PASSWORD"><?php echo e(tr('MAIL_PASSWORD')); ?> *</label>

                                <p class="text-muted" style="visibility: hidden;"><?php echo e(tr('mail_username_note')); ?></p>

                                <input type="password" class="form-control" id="MAIL_PASSWORD" name="MAIL_PASSWORD" placeholder="Enter <?php echo e(tr('MAIL_PASSWORD')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="MAIL_FROM_NAME"><?php echo e(tr('MAIL_FROM_NAME')); ?> *</label>

                                <p class="text-muted"><?php echo e(tr('MAIL_FROM_NAME_note')); ?></p>

                                <input type="text" class="form-control" id="MAIL_FROM_NAME" name="MAIL_FROM_NAME" placeholder="Enter <?php echo e(tr('MAIL_FROM_NAME')); ?>" value="<?php echo e(old('MAIL_FROM_NAME') ?: $env_values['MAIL_FROM_NAME']); ?>">
                            </div>

                            <div class="form-group">
                                <label for="MAIL_ENCRYPTION"><?php echo e(tr('MAIL_ENCRYPTION')); ?> *</label>

                                <p class="text-muted"><?php echo e(tr('mail_encryption_note')); ?></p>

                                <input type="text" class="form-control" id="MAIL_ENCRYPTION" name="MAIL_ENCRYPTION" placeholder="Enter <?php echo e(tr('MAIL_ENCRYPTION')); ?>" value="<?php echo e(old('MAIL_ENCRYPTION') ?: $env_values['MAIL_ENCRYPTION']); ?>">
                            </div>
                        </div>

                        <div class="clearfix"></div>
                    </div>

                </div>

                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>

                </div>

            </form>
       
            <br>
       
        </div>          

        <!-- Social Settings  -->
        <div class="rental-tab-content">
           
           <form id="site_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>

                <div class="box-body">
                    <div class="row">

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase"  style="color: #f30660;"><b><?php echo e(tr('site_url_settings')); ?></b></h5>

                            <hr>

                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="facebook_link"><?php echo e(tr('facebook_link')); ?> *</label>

                                <input type="text" class="form-control" id="facebook_link" name="facebook_link" placeholder="Enter <?php echo e(tr('facebook_link')); ?>" value="<?php echo e(old('facebook_link') ?: Setting::get('facebook_link')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="linkedin_link"><?php echo e(tr('linkedin_link')); ?> *</label>

                                <input type="text" class="form-control" id="linkedin_link" name="linkedin_link" placeholder="Enter <?php echo e(tr('linkedin_link')); ?>" value="<?php echo e(old('linkedin_link') ?: Setting::get('linkedin_link')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                    <label for="twitter_link"><?php echo e(tr('twitter_link')); ?> *</label>

                                    <input type="text" class="form-control" id="twitter_link" name="twitter_link" placeholder="Enter <?php echo e(tr('twitter_link')); ?>" value="<?php echo e(old('twitter_link') ?: Setting::get('twitter_link')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="google_plus_link"><?php echo e(tr('google_plus_link')); ?> *</label>

                                <input type="text" class="form-control" id="google_plus_link" name="google_plus_link" placeholder="Enter <?php echo e(tr('google_plus_link')); ?>" value="<?php echo e(old('google_plus_link') ?: Setting::get('google_plus_link')); ?>">
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="pinterest_link"><?php echo e(tr('pinterest_link')); ?> *</label>

                                <input type="text" class="form-control" id="pinterest_link" name="pinterest_link" placeholder="Enter <?php echo e(tr('pinterest_link')); ?>" value="<?php echo e(old('pinterest_link') ?: Setting::get('pinterest_link')); ?>">
                            </div>
                        </div>
                        
                        <div class="clearfix"></div>
                        
                    </div>
                
                </div>
                
                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
        
                </div>
        
            </form>
        
            <br>
        
        </div>

        <!--Social login-->
        <div class="rental-tab-content">
           
           <form id="social_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="row">

                        <div class="col-md-12">
                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('fb_settings')); ?></b></h5>
                            <hr>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="FB_CLIENT_ID"><?php echo e(tr('FB_CLIENT_ID')); ?> *</label>

                                <input type="text" class="form-control" name="FB_CLIENT_ID" id="FB_CLIENT_ID" placeholder="Enter <?php echo e(tr('FB_CLIENT_ID')); ?>" value="<?php echo e(old('FB_CLIENT_ID') ?: Setting::get('FB_CLIENT_ID')); ?>">
                            </div>
                        </div>
                       
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="FB_CLIENT_SECRET"><?php echo e(tr('FB_CLIENT_SECRET')); ?> *</label>

                                <input type="text" class="form-control" name="FB_CLIENT_SECRET" id="FB_CLIENT_SECRET" placeholder="Enter <?php echo e(tr('FB_CLIENT_SECRET')); ?>" value="<?php echo e(old('FB_CLIENT_SECRET') ?: Setting::get('FB_CLIENT_SECRET')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="FB_CALL_BACK"><?php echo e(tr('FB_CALL_BACK')); ?> *</label>

                                <input type="text" class="form-control" name="FB_CALL_BACK" id="FB_CALL_BACK" placeholder="Enter <?php echo e(tr('FB_CALL_BACK')); ?>" value="<?php echo e(old('FB_CALL_BACK') ?: Setting::get('FB_CALL_BACK')); ?>">
                            </div>
                        </div>

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('google_settings')); ?></b></h5>

                            <hr>

                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="GOOGLE_CLIENT_ID"><?php echo e(tr('GOOGLE_CLIENT_ID')); ?> *</label>

                                <input type="text" class="form-control" name="GOOGLE_CLIENT_ID" id="GOOGLE_CLIENT_ID" placeholder="Enter <?php echo e(tr('GOOGLE_CLIENT_ID')); ?>" value="<?php echo e(old('GOOGLE_CLIENT_ID') ?: Setting::get('GOOGLE_CLIENT_ID')); ?>">
                            </div>
                        </div>
                       
                         <div class="col-md-6">
                            <div class="form-group">
                                <label for="GOOGLE_CLIENT_SECRET"><?php echo e(tr('GOOGLE_CLIENT_SECRET')); ?> *</label>

                                <input type="text" class="form-control" name="GOOGLE_CLIENT_SECRET" id="GOOGLE_CLIENT_SECRET" placeholder="Enter <?php echo e(tr('GOOGLE_CLIENT_SECRET')); ?>" value="<?php echo e(old('GOOGLE_CLIENT_SECRET') ?: Setting::get('GOOGLE_CLIENT_SECRET')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="GOOGLE_CALL_BACK"><?php echo e(tr('GOOGLE_CALL_BACK')); ?> *</label>

                                <input type="text" class="form-control" name="GOOGLE_CALL_BACK" id="GOOGLE_CALL_BACK" placeholder="Enter <?php echo e(tr('GOOGLE_CALL_BACK')); ?>" value="<?php echo e(old('GOOGLE_CALL_BACK') ?: Setting::get('GOOGLE_CALL_BACK')); ?>">
                            </div>
                        </div>

                    </div>
                
                </div>
                
                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
        
                </div>
        
            </form>
        
            <br>
        
        </div>

        <!--Notification settings -->
        <div class="rental-tab-content">
           
           <form id="social_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>
                
                <div class="box-body">
                
                    <div class="row">

                        <div class="col-md-12">
                            <h5 class="settings-sub-header text-uppercase" style="color: #f30660;"><b><?php echo e(tr('notification_settings')); ?></b></h5>
                            <hr>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">

                                <label for="user_fcm_sender_id"><?php echo e(tr('user_fcm_sender_id')); ?></label>

                                <input type="text" class="form-control" name="user_fcm_sender_id" id="user_fcm_sender_id"
                                value="<?php echo e(Setting::get('user_fcm_sender_id')); ?>" placeholder="<?php echo e(tr('user_fcm_sender_id')); ?>">
                            </div>
                        </div>  

                        <div class="col-md-6">
                            <div class="form-group">

                                <label for="user_fcm_server_key"><?php echo e(tr('user_fcm_server_key')); ?></label>

                                <input type="text" class="form-control" name="user_fcm_server_key" id="user_fcm_server_key"
                                value="<?php echo e(Setting::get('user_fcm_server_key')); ?>" placeholder="<?php echo e(tr('user_fcm_server_key')); ?>">
                            </div>
                        </div> 
                        
                        <div class="col-md-6">
                            <div class="form-group">

                                <label for="provider_fcm_sender_id"><?php echo e(tr('provider_fcm_sender_id')); ?></label>

                                <input type="text" class="form-control" name="provider_fcm_sender_id" id="provider_fcm_sender_id"
                                value="<?php echo e(Setting::get('provider_fcm_sender_id')); ?>" placeholder="<?php echo e(tr('provider_fcm_sender_id')); ?>">
                            </div>
                        </div>  

                        <div class="col-md-6">
                            <div class="form-group">

                                <label for="provider_fcm_server_key"><?php echo e(tr('provider_fcm_server_key')); ?></label>

                                <input type="text" class="form-control" name="provider_fcm_server_key" id="provider_fcm_server_key"
                                value="<?php echo e(Setting::get('provider_fcm_server_key')); ?>" placeholder="<?php echo e(tr('provider_fcm_server_key')); ?>">
                            </div>
                        </div>

                    </div>  
        
                </div> 

                <div class="box-footer">

                   <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                   <?php if(Setting::get('admin_delete_control') == 1): ?>
                       <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                   <?php else: ?>
                       <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                   <?php endif; ?>
               
                </div> 
            
            </form>
            <br>

        </div>  

        <!-- APP Url Settings -->
        <div class="rental-tab-content">
            
            <form id="site_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>
                
                <div class="box-body">
                        
                    <div class="row">

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase"  style="color: #f30660;"><b><?php echo e(tr('mobile_settings')); ?></b></h5>

                            <hr>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="playstore_user"><?php echo e(tr('playstore_user')); ?> *</label>
                                <input type="text" class="form-control" id="playstore_user" name="playstore_user" placeholder="Enter <?php echo e(tr('playstore_user')); ?>" value="<?php echo e(old('playstore_user') ?: Setting::get('playstore_user')); ?>">
                            </div>

                        </div>

                        <div class="col-md-6">
                             <div class="form-group">
                                <label for="appstore_user"><?php echo e(tr('appstore_user')); ?> *</label>

                                <input type="text" class="form-control" id="appstore_user" name="appstore_user" placeholder="Enter <?php echo e(tr('appstore_user')); ?>" value="<?php echo e(old('appstore_user') ?: Setting::get('appstore_user')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">

                           <div class="form-group">
                                <label for="playstore_provider"><?php echo e(tr('playstore_provider')); ?> *</label>

                                <input type="text" class="form-control" id="playstore_provider" name="playstore_provider" placeholder="Enter <?php echo e(tr('playstore_provider')); ?>" value="<?php echo e(old('playstore_provider') ?: Setting::get('playstore_provider')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="appstore_provider"><?php echo e(tr('appstore_provider')); ?> *</label>

                                <input type="text" class="form-control" id="appstore_provider" name="appstore_provider" placeholder="Enter <?php echo e(tr('appstore_provider')); ?>" value="<?php echo e(old('appstore_provider') ?: Setting::get('appstore_provider')); ?>">
                            </div>
                        </div>
                        
                    </div>

                </div>

                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
       
                </div>
       
            </form>
       
            <br>
       
        </div>

        <!-- OTHER Settings -->

        <div class="rental-tab-content">
        
            <form id="site_settings_save" action="<?php echo e(route('admin.settings.save')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>
                
                <div class="box-body"> 
                    <div class="row"> 

                        <div class="col-md-12">

                            <h5 class="settings-sub-header text-uppercase"  style="color: #f30660;"><b><?php echo e(tr('other_settings')); ?></b></h5>

                            <hr>

                        </div>

                        <div class="col-lg-12">

                            <div class="form-group">
                                <label for="google_analytics"><?php echo e(tr('google_analytics')); ?></label>
                                <textarea class="form-control" id="google_analytics" name="google_analytics"><?php echo e(Setting::get('google_analytics')); ?></textarea>
                            </div>

                        </div> 

                        <div class="col-lg-12">

                            <div class="form-group">
                                <label for="header_scripts"><?php echo e(tr('header_scripts')); ?></label>
                                <textarea class="form-control" id="header_scripts" name="header_scripts"><?php echo e(Setting::get('header_scripts')); ?></textarea>
                            </div>

                        </div> 

                        <div class="col-lg-12">

                            <div class="form-group">
                                <label for="body_scripts"><?php echo e(tr('body_scripts')); ?></label>
                                <textarea class="form-control" id="body_scripts" name="body_scripts"><?php echo e(Setting::get('body_scripts')); ?></textarea>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">

                    <button type="reset" class="btn btn-warning"><?php echo e(tr('reset')); ?></button>

                    <?php if(Setting::get('admin_delete_control') == 1): ?>
                        <button type="submit" class="btn btn-primary pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
                
                </div>

            </form>
        
            <br>
        
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    
    $(document).ready(function() {
        $("div.rental-tab-menu>div.list-group>a").click(function(e) {
            e.preventDefault();
            $(this).siblings('a.active').removeClass("active");
            $(this).addClass("active");
            var index = $(this).index();
            $("div.rental-tab>div.rental-tab-content").removeClass("active");
            $("div.rental-tab>div.rental-tab-content").eq(index).addClass("active");
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>