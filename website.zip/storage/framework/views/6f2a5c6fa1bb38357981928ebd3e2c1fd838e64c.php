<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
       
        <li class="nav-item" id="dashboard" >
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="icon-rocket menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('dashboard')); ?></span>
            </a>
        </li>

        <li class="nav-item" id="users">
            <a class="nav-link" data-toggle="collapse" href="#users-sidebar" aria-expanded="false" aria-controls="users-sidebar">
                <i class="icon-user menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('users')); ?></span>
            </a>

            <div class="collapse" id="users-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="users-create" href="<?php echo e(route('admin.users.create')); ?> "> <?php echo e(tr('add_user')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="users-view" href=" <?php echo e(route('admin.users.index')); ?> "> <?php echo e(tr('view_users')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li> 

        <li class="nav-item" id="providers">
            <a class="nav-link" data-toggle="collapse" href="#providers-sidebar" aria-expanded="false" aria-controls="providers-sidebar">
                <i class="icon-people menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('providers')); ?></span>
            </a>

            <div class="collapse" id="providers-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="providers-create" href="<?php echo e(route('admin.providers.create')); ?> "> <?php echo e(tr('add_provider')); ?> </a>
                    </li>
                   
                    <li class="nav-item"> 
                        <a class="nav-link" id="providers-view" href=" <?php echo e(route('admin.providers.index')); ?> "> <?php echo e(tr('view_providers')); ?>  </a>
                    </li>  

                    <li class="nav-item"> 
                        <a class="nav-link" id="providers-documents" href=" <?php echo e(route('admin.providers.documents.index')); ?> "> <?php echo e(tr('documents')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li>

        <li class="nav-item nav-item-header">

            <a class="nav-link background-color">
                <span class="menu-title text-uppercase"><?php echo e(tr('space')); ?> Management</span>
            </a>
            
        </li>

        <li class="nav-item" id="categories" style="display: none">
            <a class="nav-link" data-toggle="collapse" href="#categories-sidebar" aria-expanded="false" aria-controls="categories-sidebar">
                <i class="icon-list menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('categories')); ?></span>
            </a>

            <div class="collapse" id="categories-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="categories-create" href="<?php echo e(route('admin.categories.create')); ?> "> <?php echo e(tr('add_category')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="categories-view" href=" <?php echo e(route('admin.categories.index')); ?> "> <?php echo e(tr('view_categories')); ?> </a>
                    </li>                    
                </ul>
            </div>
        </li>        

        <li class="nav-item" id="amenities">
            <a class="nav-link" data-toggle="collapse" href="#amenities-sidebar" aria-expanded="false" aria-controls="amenities-sidebar">
                <i class="icon-list menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('amenities')); ?></span>
            </a>

            <div class="collapse" id="amenities-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="amenities-create" href="<?php echo e(route('admin.amenities.create')); ?> "> <?php echo e(tr('add_amenity')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="amenities-view" href=" <?php echo e(route('admin.amenities.index')); ?> "> <?php echo e(tr('view_amenities')); ?> </a>
                    </li>                    
                </ul>
            </div>
        </li>

        <!-- <li class="nav-item" id="sub_categories">
            <a class="nav-link" data-toggle="collapse" href="#sub_categories-sidebar" aria-expanded="false" aria-controls="sub_categories-sidebar">
                <i class="icon-layers menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('sub_categories')); ?></span>
            </a>

            <div class="collapse" id="sub_categories-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="sub_categories-create" href="<?php echo e(route('admin.sub_categories.create')); ?> "> <?php echo e(tr('add_sub_category')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="sub_categories-view" href=" <?php echo e(route('admin.sub_categories.index')); ?> "> <?php echo e(tr('view_sub_categories')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li> -->

        <li class="nav-item" id="questions" style="display: none;">
            <a class="nav-link" data-toggle="collapse" href="#questions-sidebar" aria-expanded="false" aria-controls="questions-sidebar">
                <i class="icon-question menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('questions')); ?></span>
            </a>

            <div class="collapse" id="questions-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="questions-create" href="<?php echo e(route('admin.questions.create')); ?> "> <?php echo e(tr('add_question')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="questions-view" href=" <?php echo e(route('admin.questions.index')); ?> "> <?php echo e(tr('view_questions')); ?>  </a>
                    </li>

                    <li class="nav-item" style="display: none;"> 
                        <a class="nav-link" id="question_groups-view" href=" <?php echo e(route('admin.question_groups.index')); ?> "> <?php echo e(tr('view_question_groups')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li>

        <li class="nav-item" id="service-locations">

            <a class="nav-link" data-toggle="collapse" href="#service-locations-sidebar" aria-expanded="false" aria-controls="service-locations-sidebar">
                <i class="menu-icon fa fa-globe"></i>
                <span class="menu-title"><?php echo e(tr('service_locations')); ?></span>
            </a>

            <div class="collapse" id="service-locations-sidebar">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="service-locations-create" href="<?php echo e(route('admin.service_locations.create')); ?> "> <?php echo e(tr('add_service_location')); ?> </a>
                    </li>

                    <li class="nav-item"> 
                        <a class="nav-link" id="service-locations-view" href=" <?php echo e(route('admin.service_locations.index')); ?> "> <?php echo e(tr('view_service_locations')); ?>  </a>
                    </li>
                </ul>
            </div>

        </li>

        <li class="nav-item" id="hosts">

            <a class="nav-link" data-toggle="collapse" href="#hosts-sidebar" aria-expanded="false" aria-controls="hosts-sidebar">
                <i class="icon-basket menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('parking_space')); ?></span>
            </a>

            <div class="collapse" id="hosts-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="hosts-create" href="<?php echo e(route('admin.spaces.create')); ?> "> <?php echo e(tr('add_space')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="hosts-view" href=" <?php echo e(route('admin.spaces.index')); ?> "> <?php echo e(tr('view_space')); ?>  </a>
                    </li>

                    <li class="nav-item"> 
                        <a class="nav-link" id="hosts-unverified" href=" <?php echo e(route('admin.spaces.index' , ['unverified' => YES])); ?> "> <?php echo e(tr('unverified_spaces')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li>

        <li class="nav-item" id="provider_subscriptions">
            <a class="nav-link" data-toggle="collapse" href="#provider_subscriptions-sidebar" aria-expanded="false" aria-controls="provider_subscriptions-sidebar">
                <i class="icon-key menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('provider_subscriptions')); ?></span>
            </a>

            <div class="collapse" id="provider_subscriptions-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="provider_subscriptions-create" href="<?php echo e(route('admin.provider_subscriptions.create')); ?> "> <?php echo e(tr('add_provider_subscription')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="provider_subscriptions-view" href=" <?php echo e(route('admin.provider_subscriptions.index')); ?> "> <?php echo e(tr('view_provider_subscriptions')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li>

        <li class="nav-item nav-item-header">

            <a class="nav-link background-color">
                <span class="menu-title text-uppercase">Booking Management</span>
            </a>
            
        </li>

        <!-- <li class="nav-item" id="bookings">
           
            <a class="nav-link" data-toggle="collapse" href="#bookings-sidebar" aria-expanded="false" aria-controls="bookings-sidebar">
                <i class="icon-calendar menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('bookings')); ?></span>
            </a>

            <div class="collapse" id="bookings-sidebar">

                <ul class="nav flex-column sub-menu">

                    <li class="nav-item"> 
                        <a class="nav-link" id="bookings-index" href=" <?php echo e(route('admin.bookings.index')); ?> "> <?php echo e(tr('bookings')); ?>  </a>
                    </li> 

                </ul>

            </div>

        </li>         -->

        <li class="nav-item" id="bookings">
            <a class="nav-link" data-toggle="collapse" href="#bookings-sidebar" aria-expanded="false" aria-controls="bookings-sidebar">
                <i class="icon-calendar menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('bookings')); ?></span>
            </a>

            <div class="collapse" id="bookings-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="bookings-dashboard" href="<?php echo e(route('admin.bookings.dashboard')); ?> "> <?php echo e(tr('dashboard')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="bookings-view" href=" <?php echo e(route('admin.bookings.index')); ?> "> <?php echo e(tr('history')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li>

        <li class="nav-item" id="revenues">

            <a class="nav-link" data-toggle="collapse" href="#revenues-sidebar" aria-expanded="false" aria-controls="revenues-sidebar">
                <i class="icon-credit-card menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('revenues')); ?></span>
            </a>

            <div class="collapse" id="revenues-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="revenues-dashboard" href="<?php echo e(route('admin.revenues.dashboard')); ?> "> <?php echo e(tr('dashboard')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="revenues-payments" href=" <?php echo e(route('admin.bookings.payments')); ?> "> <?php echo e(tr('bookings_payments')); ?>  </a>
                    </li> 

                    <li class="nav-item"> 
                        <a class="nav-link" id="revenues-provider_subscription-payments" href=" <?php echo e(route('admin.provider_subscriptions.payments')); ?> "> <?php echo e(tr('subscription_payments')); ?>  </a>
                    </li>

                    <li class="nav-item"> 
                        <a class="nav-link" id="revenues-provider_redeems" href=" <?php echo e(route('admin.provider_redeems.index')); ?> "> <?php echo e(tr('provider_redeems')); ?>  </a>
                    </li> 

                    <li class="nav-item"> 
                        <a class="nav-link" id="revenues-user_refunds" href=" <?php echo e(route('admin.user_refunds.index')); ?> "> <?php echo e(tr('user_refunds')); ?>  </a>
                    </li> 
                                       
                </ul>

            </div>

        </li>

        <li class="nav-item" id="reviews">

            <a class="nav-link" data-toggle="collapse" href="#reviews-sidebar" aria-expanded="false" aria-controls="reviews-sidebar">
                <i class="icon-star menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('reviews')); ?></span>
            </a>

            <div class="collapse" id="reviews-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="reviews-user" href="<?php echo e(route('admin.reviews.users')); ?> "> <?php echo e(tr('user_reviews')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="reviews-provider" href=" <?php echo e(route('admin.reviews.providers')); ?> "> <?php echo e(tr('provider_reviews')); ?>  </a>
                    </li>                    
                </ul>
            </div>

        </li>

        <li class="nav-item nav-item-header">

            <a class="nav-link background-color">
                <span class="menu-title text-uppercase">Settings Management</span>
            </a>
            
        </li>

        <li class="nav-item" id="settings">
            <a class="nav-link" href="<?php echo e(route('admin.settings')); ?>" id="settings-view">
                <i class="icon-settings menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('settings')); ?></span>
            </a>
        </li>

        <li class="nav-item" id="static_pages">
            <a class="nav-link" data-toggle="collapse" href="#static_pages-sidebar" aria-expanded="false" aria-controls="static_pages-sidebar">
                <i class="icon-bubbles menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('static_pages')); ?></span>
            </a>

            <div class="collapse" id="static_pages-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="static_pages-create" href="<?php echo e(route('admin.static_pages.create')); ?> "> <?php echo e(tr('add_static_page')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="static_pages-view" href=" <?php echo e(route('admin.static_pages.index')); ?> "> <?php echo e(tr('view_static_pages')); ?>  </a>
                    </li>                    
                </ul>

            </div>

        </li> 

        <li class="nav-item" id="documents">
            <a class="nav-link" data-toggle="collapse" href="#documents-sidebar" aria-expanded="false" aria-controls="documents-sidebar">
                <i class="icon-book-open menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('documents')); ?></span>
            </a>

            <div class="collapse" id="documents-sidebar">

                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> 
                        <a class="nav-link" id="documents-create" href="<?php echo e(route('admin.documents.create')); ?> "> <?php echo e(tr('add_document')); ?> </a>
                    </li>
                    <li class="nav-item"> 
                        <a class="nav-link" id="documents-view" href=" <?php echo e(route('admin.documents.index')); ?> "> <?php echo e(tr('view_documents')); ?>  </a>
                    </li>                    
                </ul>

            </div>

        </li>

        <li class="nav-item" id="help">
            <a class="nav-link" href="<?php echo e(route('admin.help')); ?>">
                <i class="icon-directions menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('help')); ?></span>
            </a>
        </li>

        <li class="nav-item" id="logout">
            <a class="nav-link" href="<?php echo e(route('admin.logout')); ?>">
                <i class="fa fa-power-off menu-icon"></i>
                <span class="menu-title"><?php echo e(tr('logout')); ?></span>
            </a>
        </li>

    </ul>
</nav>