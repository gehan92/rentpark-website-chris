 

<?php $__env->startSection('title', tr('help')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('help')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 
	
	<div class="col-lg-12 grid-margin stretch-card">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('help')); ?></h4>

            </div>

    		<div class="card-body help">
                <p>
                    We would like to thank you for choosing Pro Coder. Kudos from our team!!
                </p>

                <p>
                    If you want to make any changes to your site, drop a mail to support@procoder.us or Skype us @ support@procoder.us and we will help you out!
                </p>
                <a href="https://www.facebook.com/procoderteam/" target="_blank"><img class="aligncenter size-full wp-image-159 help-image" src="<?php echo e(asset('helpsocial/Facebook.png')); ?>" alt="Facebook-100" width="100" height="100"></a>
                &nbsp;

                <a href="https://twitter.com/procodertea," target="_blank"><img class="size-full wp-image-155 alignleft help-image" src="<?php echo e(asset('helpsocial/twitter.png')); ?>" alt="Twitter" width="100" height="100"></a>
                &nbsp;

                <a href="skype:support@procoder.us?chat" target="_blank"> <img class="wp-image-158 alignleft help-image" src="<?php echo e(asset('helpsocial/skype.png')); ?>" alt="skype" width="100" height="100"></a>
                &nbsp;

                <a href="mailto:support@procoder.us" target="_blank"><img class="size-full wp-image-153 alignleft help-image" src="<?php echo e(asset('helpsocial/mail.png')); ?>" alt="Message-100" width="100" height="100"></a>

	             &nbsp;

	            <p>
                    We have this team of innate developers and dedicated team of support to sort out the things for your benefits. Tell us what you like about Rentcubo and we may suggest you the best solution for you :)
                </p>

      			<a href="https://procoder.us" target="_blank"><img class="aligncenter help-image size-full wp-image-160" src="<?php echo e(asset('helpsocial/Money-Box-100.png')); ?>" alt="Money Box-100" width="100" height="100"></a>

				<p>Cheers!</p>

    		</div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>