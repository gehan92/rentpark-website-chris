 

<?php $__env->startSection('title', tr('user_refunds')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a><?php echo e(tr('revenues')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('user_refunds')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

	<div class="col-lg-12 grid-margin">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('user_refunds')); ?></h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">

                	<table id="order-listing" class="table">
                        
                        <thead>

                            <tr>
								<th><?php echo e(tr('s_no')); ?></th>
								<th><?php echo e(tr('user')); ?></th>                              
								<th><?php echo e(tr('total')); ?></th>
                                <th><?php echo e(tr('paid_amount')); ?></th>
                                <th><?php echo e(tr('remaining')); ?></th>
                                <th><?php echo e(tr('paid_date')); ?></th>
								<th><?php echo e(tr('action')); ?></th>
                            </tr>

                        </thead>
                        
                        <tbody>

                            <?php if(count($user_refunds) > 0 ): ?>
                            
                                <?php $__currentLoopData = $user_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user_refund_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($i+1); ?></td>
                                                                                

                                        <td>
                                            <?php if(empty($user_refund_details->user_name)): ?>

                                                <?php echo e(tr('user_not_avail')); ?>

                                            
                                            <?php else: ?>
                                                <a href="<?php echo e(route('admin.users.view',['user_id' => $user_refund_details->user_id])); ?>"><?php echo e($user_refund_details->user_name); ?></a>
                                            <?php endif; ?>
                                        </td>
                                        
                                        <td>
                                            <?php echo e(formatted_amount($user_refund_details->total)); ?>                   
                                        </td>

                                        <td>
                                            <?php echo e(formatted_amount($user_refund_details->paid_amount)); ?>                   
                                        </td>

                                        <td>
                                            <?php echo e(formatted_amount($user_refund_details->remaining_amount)); ?>                   
                                        </td>

                                        <td>
                                            <?php echo e(common_date($user_refund_details->paid_date)); ?>                   
                                        </td>

                                        <td>
                                            <?php if($user_refund_details->remaining_amount >0): ?>

                                                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#UserRefundModel"><?php echo e(tr('pay_now')); ?></button>
                                        
                                            <?php else: ?>
                                                <div class="badge badge-success badge-fw"><?php echo e(tr('paid')); ?></div>
                                            <?php endif; ?>
                                        </td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>

                                <tr>
                                    <td><?php echo e(tr('no_result_found')); ?></td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>	
<?php $__currentLoopData = $user_refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user_refund_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($user_refund_details->remaining_amount): ?>
            <div id="UserRefundModel" class="modal fade" role="dialog">

                <div class="modal-dialog">

                    <div class="modal-content">
                
                        <div class="modal-header">
                            
                            <h4 class="modal-title pull-left"><a href="<?php echo e(route('admin.users.view',['user_id' => $user_refund_details->user_id])); ?>"><?php echo e($user_refund_details->user_name); ?></a></h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-sm">
                                    <b><?php echo e(tr('account_name')); ?></b>
                                    <p><?php echo e($user_refund_details->account_name); ?></p>
                                </div>
                                <div class="col-sm">
                                    <b><?php echo e(tr('account_no')); ?></b>
                                    <p><?php echo e($user_refund_details->account_no); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm">
                                    <b><?php echo e(tr('route_no')); ?></b>
                                    <p><?php echo e($user_refund_details->route_no); ?></p>
                                </div>
                                <div class="col-sm">
                                    <b><?php echo e(tr('remaining')); ?></b>
                                    <p><?php echo e(formatted_amount($user_refund_details->remaining_amount)); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm">
                                    <b><?php echo e(tr('paypal_email')); ?></b>
                                    <p><?php echo e($user_refund_details->paypal_email); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                    
                                <form class="forms-sample" action="<?php echo e(route('admin.user_refunds.payment')); ?>" method="POST" enctype="multipart/form-data" role="form" >
                                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="user_refund_id" id="user_refund_id" value="<?php echo e($user_refund_details->id); ?>">

                                    <input type="hidden" class="form-control" id="amount" name="amount" value="<?php echo e($user_refund_details->remaining_amount); ?>" required>

                                    <button type="submit" class="btn btn-info btn-sm"  onclick="return confirm(&quot;<?php echo e(tr('user_payment_confirmation')); ?>&quot;);"><?php echo e(tr('pay_now')); ?></button>
                            </form>
        
                            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(tr('close')); ?></button>
                        </div>
                    </div>

                </div>
            </div> 
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>