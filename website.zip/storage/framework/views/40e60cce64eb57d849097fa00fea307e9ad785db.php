<div class="col-lg-12 grid-margin stretch-card">

    <div class="row flex-grow">

        <div class="col-12 grid-margin">

            <div class="card">  

            <form class="forms-sample" action="<?php echo e(Setting::get('is_demo_control_enabled') == NO ? route('admin.provider_subscriptions.save') : '#'); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php echo csrf_field(); ?>

                    <div class="card-header bg-card-header ">

                        <h4 class=""><?php echo e(tr('provider_subscription')); ?>


                            <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.provider_subscriptions.index')); ?>">
                                <i class="fa fa-eye"></i> <?php echo e(tr('view_provider_subscriptions')); ?>

                            </a>
                        </h4>

                    </div>

                    <div class="card-body">

                        <input type="hidden" name="provider_subscription_id" id="provider_subscription_id" value="<?php echo e($provider_subscription_details->id); ?>">

                        <div class="row">

                            <div class="form-group col-md-6">

                                <label for="title" class=""><?php echo e(tr('title')); ?> <span class="admin-required">*</span></label>

                                <input type="text" name="title" class="form-control" id="title" value="<?php echo e(old('title') ?: $provider_subscription_details->title); ?>" placeholder="<?php echo e(tr('title')); ?>" required >
                                
                            </div>
                            
                            <!-- <div class="form-group"> -->
                            <div class="form-group col-md-6">

                                <label for="plan"><?php echo e(tr('no_of_months')); ?> <span class="admin-required">*</span></label>

                                <input type="number" min="1" max="12" required name="plan" class="form-control" id="plan" value="<?php echo e(old('plan') ?: $provider_subscription_details->plan); ?>" title="<?php echo e(tr('plan')); ?>" placeholder="<?php echo e(tr('no_of_months')); ?>">
                            </div>

                        </div>

                        <div class="row">
                        
                            <div class="form-group col-md-6">

                                <label for="amount" class=""><?php echo e(tr('amount')); ?> <span class="admin-required">*</span></label>

                                <input type="number" value="<?php echo e(old('amount') ?: $provider_subscription_details->amount); ?>" name="amount" class="form-control" id="amount" placeholder="<?php echo e(tr('amount')); ?>" min="0" step="any" required>
                            </div>

                        </div>

                        <!--    <div class="row">

                            <div class="form-group col-md-6">

                                <label><?php echo e(tr('upload_image')); ?></label>

                                <input type="file" name="picture" class="file-upload-default" accept="image/*">

                                <div class="input-group col-xs-12">

                                    <input type="text" class="form-control file-upload-info" disabled placeholder="<?php echo e(tr('upload_image')); ?>">

                                    <div class="input-group-append">
                                        <button class="file-upload-browse btn btn-info" type="button"><?php echo e(tr('upload')); ?></button>
                                    </div>
                                </div>
                            </div>

                        </div> -->

                        <div class="row">

                            <div class="form-group col-md-12">

                                <label for="simpleMde"><?php echo e(tr('description')); ?></label>

                                <textarea class="form-control" id="description" name="description"><?php echo e(old('description') ?: $provider_subscription_details->description); ?></textarea>

                            </div>

                        </div>

                    </div>                    

                    <div class="card-footer">

                        <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                        <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <button type="submit" class="btn btn-success mr-2"><?php echo e(tr('submit')); ?> </button>

                        <?php else: ?>

                            <button type="button" class="btn btn-success mr-2" disabled><?php echo e(tr('submit')); ?></button>
                            
                        <?php endif; ?>

                    </div>

                </form>

                </div>

            </div>

        </div>

    </div>
    
</div>

