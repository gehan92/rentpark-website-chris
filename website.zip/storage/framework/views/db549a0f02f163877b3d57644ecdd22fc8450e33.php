 

<?php $__env->startSection('title', tr('subscription_payments')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a><?php echo e(tr('revenues')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('subscription_payments')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

	<div class="col-lg-12 grid-margin">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('subscription_payments')); ?></h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">
                
                	<table id="order-listing" class="table">
                        
                        <thead>
                            <tr>
                                <th><?php echo e(tr('id')); ?></th>
                                <th><?php echo e(tr('provider')); ?></th>
                                <th><?php echo e(tr('subscriptions')); ?></th>
                                <th><?php echo e(tr('payment_id')); ?></th>
                                <th><?php echo e(tr('plan')); ?></th>
                                <th><?php echo e(tr('total')); ?> </th>
                                <th><?php echo e(tr('status')); ?></th>
                                <th><?php echo e(tr('is_cancelled')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>

                        </thead>
                                               
                        <tbody>

                            <?php $__currentLoopData = $provider_subscription_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $provider_subscription_payment_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($i+1); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('admin.providers.view' , ['provider_id' => $provider_subscription_payment_details->provider_id ])); ?>"><?php echo e($provider_subscription_payment_details->providerDetails->name ?? tr('provider_not_avail')); ?></a>
                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('admin.provider_subscriptions.view' ,['provider_subscription_id' => $provider_subscription_payment_details->provider_subscription_id])); ?>"><?php echo e($provider_subscription_payment_details->providerSubscriptionDetails->title ?? tr('provider_subscription_not_avail')); ?></a>
                                    </td>
                                  
                                    <td>
                                        <?php echo e($provider_subscription_payment_details->payment_id); ?>

                                        <br>
                                        <small><?php echo e(tr('paid_at')); ?>: <?php echo e(common_date($provider_subscription_payment_details->updated_at, Auth::guard('admin')->user()->timezone)); ?></small>
                                    </td>

                                    <td>
                                        <?php echo e(plan_text( $provider_subscription_payment_details->providerSubscriptionDetails->plan ?? '0',  $provider_subscription_payment_details->providerSubscriptionDetails->plan_type ?? '')); ?>


                                        <br>
                                        <small class="text-success"><?php echo e(tr('expiry_at')); ?>: <?php echo e(common_date($provider_subscription_payment_details->expiry_date, Auth::guard('admin')->user()->timezone)); ?></small>

                                    </td>

                                    <td>
                                        <?php echo e(formatted_amount($provider_subscription_payment_details->paid_amount)); ?>

                                    </td>

                                    <td>
                                        <?php if($provider_subscription_payment_details->status ): ?> 
                                           
                                           <span class="badge badge-success badge-fw"><?php echo e(tr('paid')); ?></span>

                                        <?php else: ?>
                                           
                                            <span class="badge badge-danger badge-fw"><?php echo e(tr('not_paid')); ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php if( $provider_subscription_payment_details->is_cancelled ): ?> 
                                            <span class="badge badge-success badge-fw"><?php echo e(tr('yes')); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-danger badge-fw"><?php echo e(tr('no')); ?></span>

                                        <?php endif; ?>
                                    </td>

                                     <td>
                                            <a class="btn btn-primary" href="<?php echo e(route('admin.provider.subscriptions.payments.view', ['id' => $provider_subscription_payment_details->id] )); ?>">
                                                <?php echo e(tr('view')); ?>

                                            </a> 
                                    </td>

                                    

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                     
                </div>

            </div>

        </div>

    </div>	
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>