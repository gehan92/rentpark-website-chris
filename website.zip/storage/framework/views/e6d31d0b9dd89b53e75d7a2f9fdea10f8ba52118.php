 

<?php $__env->startSection('title', tr('add_document')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item">
    	<a href="<?php echo e(route('admin.documents.index')); ?>"><?php echo e(tr('documents')); ?></a>
    </li>
    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('add_document')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

	<?php echo $__env->make('admin.documents._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>