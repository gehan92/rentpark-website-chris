 

<?php $__env->startSection('title', tr('view_amenities')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.amenities.index')); ?>"><?php echo e(tr('amenities')); ?></a></li>

    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_amenities')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <div class="col-lg-12 grid-margin stretch-card">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('view_amenities')); ?>


                    <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.amenities.create')); ?>">
                        <i class="fa fa-plus"></i> <?php echo e(tr('add_amenity')); ?>

                    </a>
                </h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">
                    
                    <table id="order-listing" class="table">
                       
                        <thead>
                            <tr>
                                <th><?php echo e(tr('s_no')); ?></th>
                                <th><?php echo e(tr('picture')); ?></th>
                                <th><?php echo e(tr('sapce_type')); ?></th>
                                <th><?php echo e(tr('name')); ?></th>
                                <th><?php echo e(tr('status')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>

                        <tbody>
                         
                            <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $amenity_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    
                                    <td>
                                        <img src="<?php echo e($amenity_details->picture ?: asset('placeholder.jpg')); ?>" alt="image"> 
                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('admin.amenities.view' , ['amenity_id' => $amenity_details->id] )); ?>"> <?php echo e($amenity_details->type); ?>

                                        </a>
                                    </td>

                                    <td>
                                        <?php echo e($amenity_details->value); ?>

                                    </td>

                                    <td>                                    
                                        <?php if($amenity_details->status == APPROVED): ?>

                                            <span class="badge badge-outline-success">
                                                <?php echo e(tr('approved')); ?> 
                                            </span>

                                        <?php else: ?>

                                            <span class="badge badge-outline-danger">
                                                <?php echo e(tr('declined')); ?> 
                                            </span>
                                               
                                        <?php endif; ?>
                                    </td>
                                   
                                    <td>                                                                        
                                        <div class="dropdown">

                                            <button class="btn btn-outline-primary  dropdown-toggle btn-sm" type="button" id="dropdownMenuOutlineButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php echo e(tr('action')); ?>

                                            </button>

                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuOutlineButton1">

                                                <a class="dropdown-item" href="<?php echo e(route('admin.amenities.view', ['amenity_id' => $amenity_details->id] )); ?>"><?php echo e(tr('view')); ?>

                                                    </a>

                                                <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                                                
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.amenities.edit', ['amenity_id' => $amenity_details->id] )); ?>"><?php echo e(tr('edit')); ?>

                                                    </a>

                                                    <a class="dropdown-item" 
                                                    onclick="return confirm(&quot;<?php echo e(tr('amenity_delete_confirmation' , $amenity_details->value)); ?>&quot;);" href="<?php echo e(route('admin.amenities.delete', ['amenity_id' => $amenity_details->id] )); ?>" >
                                                        <?php echo e(tr('delete')); ?>

                                                    </a>
                                                    
                                                <?php else: ?>

                                                    <a class="dropdown-item" href="javascript:;"><?php echo e(tr('edit')); ?>

                                                    </a>

                                                    <a class="dropdown-item" href="javascript:;"><?php echo e(tr('delete')); ?>

                                                    </a>

                                                <?php endif; ?>

                                                <div class="dropdown-divider"></div>

                                                <?php if($amenity_details->status == APPROVED): ?>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.amenities.status', ['amenity_id' => $amenity_details->id] )); ?>" 
                                                    onclick="return confirm(&quot;<?php echo e($amenity_details->value); ?> - <?php echo e(tr('amenity_decline_confirmation')); ?>&quot;);"> 
                                                        <?php echo e(tr('decline')); ?>

                                                    </a>

                                                <?php else: ?>

                                                    <a class="dropdown-item" href="<?php echo e(route('admin.amenities.status', ['amenity_id' => $amenity_details->id] )); ?>">
                                                        <?php echo e(tr('approve')); ?>

                                                    </a>
                                                       
                                                <?php endif; ?>
                                                
                                            </div>
                                             
                                        </div>
                                        
                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                 
                        </tbody>
                    
                    </table>                
                </div>
    
            </div>
        
        </div>
    
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>