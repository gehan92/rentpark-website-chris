 

<?php $__env->startSection('title', tr('profile')); ?>

<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item active" aria-current="page">
    <span><?php echo e(tr('profile')); ?></span>
</li>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

<div class="row">

    <div class="col-md-6 grid-margin stretch-card">
       
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?php echo e(tr('update_profile')); ?></h4>
                 
                <?php if(Setting::get('is_demo_control_enabled') == NO): ?>

                <form action="<?php echo e((Setting::get('admin_delete_control') == ADMIN_CONTROL_ENABLED) ? '#' : route('admin.profile.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php else: ?>       
            
                <form class="forms-sample" role="form">
                
                <?php endif; ?>

                    <?php echo csrf_field(); ?>
                    
                    <input type="hidden" name="admin_id" value="<?php echo e(Auth::guard('admin') ? Auth::guard('admin')->user()->id : 0); ?>">

                    <div class="form-group">
                        <label ffor="name"><?php echo e(tr('name')); ?></label>
                        <input type="text" class="form-control" name="name" required id="name" placeholder="Enter <?php echo e(tr('name')); ?>" value="<?php echo e(old('name') ? old('name') : Auth::guard('admin')->user()->name); ?>" pattern="[a-zA-Z0-9\s\-]{2,255}">
                    </div>

                    <div class="form-group">
                        <label for="email"><?php echo e(tr('email')); ?></label>
                        <input type="email" name="email" required class="form-control" id="email" placeholder="Enter <?php echo e(tr('email')); ?>" value="<?php echo e(old('email') ? old('email') : Auth::guard('admin')->user()->email); ?>">
                    </div>

                    <div class="form-group">
                        <label for="picture"><?php echo e(tr('picture')); ?></label>
                        <input type="file" name="picture" class="form-control" id="picture" accept="image/*">
                    </div>

                    <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                    <button type="submit" class="btn btn-success ">
                        <?php echo e(tr('submit')); ?>

                    </button>
                   
                </form>

            </div>

        </div>

    </div>

    <div class="col-md-6 d-flex align-items-stretch grid-margin">
        <div class="row flex-grow">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e(tr('change_password')); ?></h4>

                        <form class="form-horizontal" action="<?php echo e((Setting::get('admin_delete_control') == YES ) ? '#' : route('admin.change.password')); ?>" method="POST" enctype="multipart/form-data" role="form">

                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="old_password"><?php echo e(tr('old_password')); ?><span class="required" aria-required="true"> * </span></label>
                                <input type="password" required class="form-control" name="old_password" id="old_password" placeholder="Enter <?php echo e(tr('old_password')); ?>" pattern=".{6,}" title="The old password must be 6 characters.">
                            </div>

                            <div class="form-group">
                                <label for="new_password"><?php echo e(tr('new_password')); ?><span class="required" aria-required="true"> * </span></label>
                                <input type="password" required class="form-control" name="password" id="new_password" placeholder="Enter <?php echo e(tr('new_password')); ?>" pattern=".{6,}" title="The new password must be 6 characters.">
                            </div>

                            <div class="form-group">
                                <label for="confirm_password"><?php echo e(tr('confirm_password')); ?><span class="required" aria-required="true"> * </span></label>
                                <input type="password" required class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Enter <?php echo e(tr('confirm_password')); ?>" pattern=".{6,}" title="The confirm password must be 6 characters.">
                            </div>

                            <button type="reset" class="btn btn-light">
                                <?php echo e(tr('reset')); ?>

                            </button>

                            <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                                
                                <button type="submit" class="btn btn-success mr-2">
                                    <?php echo e(tr('submit')); ?>

                                </button>

                            <?php else: ?>

                                <button type="button" class="btn btn-success mr-2" disabled><?php echo e(tr('submit')); ?></button>
                                
                            <?php endif; ?> 

                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>