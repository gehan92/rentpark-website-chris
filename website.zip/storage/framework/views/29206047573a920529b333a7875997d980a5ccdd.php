<div class="col-lg-12 grid-margin stretch-card">

    <div class="row flex-grow">

        <div class="col-12 grid-margin">

            <div class="card">

                <div class="card-header bg-card-header ">

                    <h4 class=""><?php echo e(tr('add_document')); ?>


                        <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.documents.index')); ?>">
                            <i class="fa fa-eye"></i> <?php echo e(tr('documents')); ?>

                        </a>
                    </h4>

                </div>

                <?php if(Setting::get('is_demo_control_enabled') == NO): ?>

                <form class="forms-sample" action="<?php echo e(route('admin.documents.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php else: ?>
                
                <form class="forms-sample" role="form">
                
                <?php endif; ?>

                <?php echo csrf_field(); ?>
                    
                    <div class="card-body">

                        <input type="hidden" name="document_id" id="document_id" value="<?php echo e($document_details->id); ?>">

                        <div class="row">

                            <div class="form-group col-md-12">
                                <label for="name"><?php echo e(tr('name')); ?> <span class="admin-required">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo e(tr('name')); ?>" value="<?php echo e(old('name') ?: $document_details->name); ?>" required>
                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">

                                <label for="simpleMde"><?php echo e(tr('description')); ?></label>

                                <textarea class="form-control" id="description" name="description"><?php echo e(old('description') ?: $document_details->description); ?></textarea>

                            </div>
                            
                        </div>

                    </div>

                    <div class="card-footer">

                        <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                        <?php if(Setting::get('is_demo_control_enabled') == NO): ?>
                        
                            <button type="submit" class="btn btn-success mr-2"><?php echo e(tr('submit')); ?></button>
                            
                        <?php else: ?>
                        
                            <button type="button" class="btn btn-success mr-2" disabled> <?php echo e(tr('submit')); ?></button>
                            
                        <?php endif; ?>
                      
                    </div>

                </form>
            
            </div>

        </div>
    
    </div>

</div>