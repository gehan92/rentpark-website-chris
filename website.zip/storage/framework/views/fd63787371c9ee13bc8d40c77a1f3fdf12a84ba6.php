 

<?php $__env->startSection('title', tr('provider_subscription_payments')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item active" aria-current="page">
    	<span><?php echo e(tr('provider_subscription_payments')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

	<div class="col-lg-12 grid-margin">
        
        <div class="card">

            <div class="card-header bg-card-header ">

                <h4 class=""><?php echo e(tr('provider_subscription_payments')); ?></h4>

            </div>

            <div class="card-body">

                <div class="table-responsive">

                	<table id="order-listing" class="table">
                                             
                        <thead>
                            <tr>
                                <th><?php echo e(tr('id')); ?></th>
                                <th><?php echo e(tr('name')); ?></th>
                                <th><?php echo e(tr('provider_subscription')); ?></th>
                                <th><?php echo e(tr('payment_id')); ?></th>
                                <th><?php echo e(tr('amount')); ?></th>
                                <th><?php echo e(tr('expiry_date')); ?></th>
                                <th style="display: none"><?php echo e(tr('reason')); ?></th>
                                <th style="display: none"><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $provider_subscription_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $provider_subscription_payment_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    
                                    <td><?php echo e($i+1); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('admin.providers.view', ['provider_id' => $provider_subscription_payment_details->providerDetails->id ])); ?>"><?php echo e($provider_subscription_payment_details->providerDetails->name ?? tr('provider_not_avail')); ?> </a>
                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('admin.provider_subscriptions.view', ['provider_subscription_id' => $provider_subscription_payment_details->providerSubscriptionDetails->id ])); ?>"> <?php echo e($provider_subscription_payment_details->providerSubscriptionDetails->title ?? tr('subscription_not_avail')); ?> </a> 
                                    </td>

                                    <td><?php echo e($provider_subscription_payment_details->payment_id); ?></td>

                                    <td><?php echo e(formatted_amount($provider_subscription_payment_details->paid_amount)); ?></td>

                                    <td><?php echo e(date('d M Y',strtotime($provider_subscription_payment_details->expiry_date))); ?></td>

                                    <td style="display: none"><?php echo e($provider_subscription_payment_details->cancelled_reason); ?></td>

                                    <td class="text-center" style="display :none">

                                        <?php if($i == 0 && !$provider_subscription_payment_details->is_cancelled && $provider_subscription_payment_details->status == PAID_STATUS): ?> 
                                        <a data-toggle="modal" data-target="#<?php echo e($provider_subscription_payment_details->id); ?>_cancel_subscription" class="pull-right btn btn-sm btn-danger"><?php echo e(tr('cancel_subscription')); ?></a>

                                        <?php elseif($i == 0 && $provider_subscription_payment_details->is_cancelled && $provider_subscription_payment_details->status == PAID_STATUS): ?>

                                            <?php $enable_subscription_notes = tr('enable_subscription_notes') ; ?>
                                        
                                            <a onclick="return confirm('<?php echo e($enable_subscription_notes); ?>')" href="<?php echo e(route('admin.providers.subscriptions.enable', ['provider_id' => $provider_subscription_payment_details->provider_id])); ?>" class="pull-right btn btn-sm btn-success"><?php echo e(tr('enable_subscription')); ?></a>

                                        <?php else: ?>
                                            -       
                                        <?php endif; ?>
                                    </td>

                                </tr>

                                <div class="modal fade error-popup" id="<?php echo e($provider_subscription_payment_details->id); ?>_cancel_subscription" role="dialog">

                                    <div class="modal-dialog">

                                        <div class="modal-content">

                                            <form method="post" action="<?php echo e(route('admin.providers.subscriptions.cancel', ['provider_id' => $provider_subscription_payment_details->provider_id])); ?>">

                                                <div class="modal-body">

                                                    <div class="media">

                                                        <div class="media-body">

                                                           <h4 class="media-heading"><?php echo e(tr('reason')); ?> *</h4>

                                                           <textarea rows="5" name="cancel_reason" id='cancel_reason' required style="width: 100%"></textarea>

                                                       </div>

                                                    </div>

                                                    <div class="text-right">

                                                        <br>

                                                       <button type="submit" class="btn btn-primary top"><?php echo e(tr('submit')); ?></button>

                                                   </div>

                                                </div>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
              
                </div>

            </div>

        </div>

    </div>

    <?php if(count($provider_subscriptions) > 0): ?>
                   
        <div class="row pl-2" >
      
            <?php $__currentLoopData = $provider_subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $provider_subscription_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                   
                    <div class="card card-body grid-margin ">

                        <div class="thumbnail">

                            <div class="caption">

                                <center><h4 style="margin: 10px">
                                    <a href="<?php echo e(route('admin.provider_subscriptions.view', ['provider_subscription_id' => $provider_subscription_details->id])); ?>" target="_blank"><?php echo e($provider_subscription_details->title); ?></a>
                                </h4></center>

                                <hr>

                            
                                <?php if($provider_subscription_details->description): ?>
                                    <h4><b><?php echo e(tr('description')); ?> : </b></h4>

                                    <div class="subscription-desc">
                                        <?php echo $provider_subscription_details->description; ?>
                                    </div>
                                <?php endif; ?>
                                <br>

                                <p>
                                    <span class="btn btn-danger pull-left" style="cursor: default;"><?php echo e(formatted_amount( $provider_subscription_details->amount)); ?> / <?php echo e($provider_subscription_details->plan); ?> M</span>

                                    <a href="<?php echo e(route('admin.providers.subscriptions.plans.save' , ['provider_subscription_id' => $provider_subscription_details->id, 'provider_id' => $provider_id])); ?>" class="btn btn-success pull-right"><?php echo e(tr('choose')); ?></a>
                                </p>
                                <br>
                            
                            </div>
                        
                        </div>

                    </div>
               
                </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>              

    <?php endif; ?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>