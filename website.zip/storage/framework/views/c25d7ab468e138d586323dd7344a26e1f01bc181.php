<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo e(Setting::get('site_name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/simple-line-icons/css/simple-line-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/flag-icon-css/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css')); ?>">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/font-awesome/css/font-awesome.min.css')); ?>" />
    

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/jquery-bar-rating/dist/themes/fontawesome-stars.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" />

    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/summernote/dist/summernote-bs4.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/css/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/css/custom.css')); ?>">


    <link rel="shortcut icon" href="<?php echo e(Setting::get('site_icon')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/jquery-bar-rating/dist/themes/css-stars.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/jquery-bar-rating/dist/themes/fontawesome-stars-o.css')); ?> ">

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/jquery-bar-rating/dist/themes/fontawesome-stars.css')); ?>">
  
    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/morris.js/morris.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/lightgallery/dist/css/lightgallery.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/fullcalendar/dist/fullcalendar.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/c3/c3.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/node_modules/icheck/skins/all.css')); ?>" />

    <style>
        label {
            text-transform: uppercase;
        }
        .picture{
            height: 408px;

            width: 500px;
        }
    </style>

    <?php echo $__env->yieldContent('styles'); ?>

    <?php echo Setting::get('header_scripts'); ?>

</head>

<body class="sidebar-fixed sidebar-dark">

    <div class="container-scroller">

        <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- partial -->
        <div class="container-fluid page-body-wrapper">

            <div class="row row-offcanvas row-offcanvas-right">

                <!-- partial:_sidebar-->
                <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- partial -->

                <!-- content-wrapper -->
                <div class="content-wrapper">
                    
                    <?php if(Setting::get('is_demo_control_enabled') == YES): ?>
            
                        <div class="alert alert-warning" role="alert">
                            <?php echo e(tr('admin_control_enabled_alert')); ?>

                            <a href="https://rentcubo.com/contact/">Contact Us!</a>
                        </div>

                    <?php endif; ?>  
                                        
                    <!-- partial:_breadcrum -->
                    <div class="col-md-12 grid-margin stretch-card">

                        <div class="template-demo">

                            <nav aria-label="breadcrumb" role="navigation">
                                
                                <ol class="breadcrumb breadcrumb-custom">

                                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(tr('home')); ?></a></li>
                                    
                                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                                    
                                </ol>

                            </nav>

                        </div>

                    </div>
                    <!-- partial -->

                    <?php echo $__env->make('notifications.notify', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
                <!-- content-wrapper ends -->

                <!-- partial:_footer -->

                <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- partial -->

            </div>
            <!-- row-offcanvas ends -->
        </div>
        <!-- page-body-wrapper ends -->
    
    </div>

    <!-- container-scroller -->

    <?php echo $__env->make('layouts.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>

    <?php echo Setting::get('body_scripts'); ?>

    <!-- End custom js for this page-->
</body>

</html>