<div class="col-lg-12 grid-margin stretch-card">

    <div class="row flex-grow">

        <div class="col-12 grid-margin">

            <div class="card">

                <?php if(Setting::get('is_demo_control_enabled') == NO): ?>

                <form class="forms-sample" action="<?php echo e(route('admin.vehicle_details.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php else: ?>

                <form class="forms-sample" role="form">

                <?php endif; ?> 

                    <?php echo csrf_field(); ?>

                    <div class="card-header bg-card-header ">

                        <h4 class=""><?php echo e(tr('vehicle_details')); ?></h4>

                    </div>

                    <div class="card-body">

                        <input type="hidden" name="user_id" id="user_id" value="<?php echo e($vehicle_details->user_id); ?>">

                        <input type="hidden" name="vehicle_id" id="vehicle_id" value="<?php echo e($vehicle_details->id); ?>">

                        <div class="row">

                            <div class="form-group col-md-4">
                                <label for="vehicle_number"><?php echo e(tr('vehicle_number')); ?> <span class="admin-required">*</span></label>
                                <input type="text" class="form-control" id="vehicle_number" name="vehicle_number" placeholder="<?php echo e(tr('vehicle_number')); ?>" value="<?php echo e(old('vehicle_number') ?: $vehicle_details->vehicle_number); ?>" required>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="vehicle_type"><?php echo e(tr('vehicle_type')); ?> <span class="admin-required">*</span></label>
                                <input type="text" class="form-control" id="vehicle_type" name="vehicle_type" placeholder="<?php echo e(tr('vehicle_type')); ?>" value="<?php echo e(old('vehicle_type') ?: $vehicle_details->vehicle_type); ?>" required>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="vehicle_brand"><?php echo e(tr('vehicle_brand')); ?> <span class="admin-required">*</span></label>
                                <input type="text" class="form-control" id="vehicle_brand" name="vehicle_brand" placeholder="<?php echo e(tr('vehicle_brand')); ?>" value="<?php echo e(old('vehicle_brand') ?: $vehicle_details->vehicle_brand); ?>" required>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="vehicle_model"><?php echo e(tr('vehicle_model')); ?> <span class="admin-required">*</span></label>
                                <input type="text" class="form-control" id="vehicle_model" name="vehicle_model" placeholder="<?php echo e(tr('vehicle_model')); ?>" value="<?php echo e(old('vehicle_model') ?: $vehicle_details->vehicle_model); ?>" required>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer">

                        <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                        <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <button type="submit" class="btn btn-success mr-2"><?php echo e(tr('submit')); ?> </button>

                        <?php else: ?>

                            <button type="button" class="btn btn-success mr-2" disabled><?php echo e(tr('submit')); ?></button>
                            
                        <?php endif; ?>

                    </div>

                </form>

            </div>

        </div>

    </div>
    
</div>