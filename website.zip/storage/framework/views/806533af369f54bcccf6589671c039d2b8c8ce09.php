 

<?php $__env->startSection('title', tr('view_wishlist')); ?>

<?php $__env->startSection('breadcrumb'); ?>

	<li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(tr('users')); ?></a></li>

	<li class="breadcrumb-item" aria-current="page">
	    <a href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(tr('view_users')); ?></a>
	</li> 
    
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('wishlist')); ?></span>
    </li> 
           
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

	<div class="col-lg-12 grid-margin stretch-card">
	    
	    <div class="card">

	        <div class="card-header bg-card-header ">

	            <h4 class="">

	            	<?php echo e(tr('wishlist')); ?> - 
	            	
	            	<a href="<?php echo e(route('admin.users.view',['user_id' => $user_details->id ])); ?>" class="text-white">
	            		<?php echo e($user_details->name); ?> 
	            	</a>

	                <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.users.view',['user_id' => $user_details->id ])); ?>">
	                	<i class="fa fa-eye"></i> 
	                	<?php echo e(tr('view_user')); ?>

	                </a>

	            </h4>

	        </div>

	        <div class="card-body">

	            <div class="table-responsive">

            	    <table id="order-listing" class="table">
	            	       
            	        <thead>
            	       
            	            <tr>
            	                <th><?php echo e(tr('s_no')); ?></th>
            	                <th><?php echo e(tr('host')); ?></th>
            	                <th><?php echo e(tr('action')); ?></th>
            	            </tr>
            	       
            	        </thead>
            	      
            	        <tbody>

            	            <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $wishlist_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	            	
            	            	<tr>
	            	            	
	            	            	<td><?php echo e($i+1); ?></td>

	                                <td>
	                                    <a href="<?php echo e(route('admin.spaces.view' , ['host_id' => $wishlist_details->host_id])); ?>"> <?php echo e($wishlist_details->hostDetails->host_name ?? tr('host_not_avail')); ?>

	                                    </a>
	                                </td>
	                              
	                                <td>

                                        <?php if(Setting::get('is_demo_control_enabled') == NO): ?>

                                            <a class="btn btn-danger" href="<?php echo e(route('admin.wishlists.delete', ['wishlist_id' => $wishlist_details->id])); ?>" 
                                            onclick="return confirm(&quot;<?php echo e(tr('wishlist_delete_confirmation' , $wishlist_details->hostDetails->host_name)); ?>&quot;);">
                                                <?php echo e(tr('remove')); ?>

                                            </a>
                                        <?php else: ?>
                                          
                                            <a class="btn btn-danger" href="javascript:;"><?php echo e(tr('remove')); ?></a> 

                                        <?php endif; ?>
                                                      
	                                </td>
                                
                                </tr>
    	                    
    	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	                                                         
    	                </tbody>
        	            
        	        </table>
	            
	            </div>

	        </div>
	    
	    </div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>