 

<?php $__env->startSection('title', tr('reviews')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item" aria-current="page">
    	<a href="javascript:void(0)"><?php echo e(tr('reviews')); ?></a>
    </li>

    <?php if($sub_page == 'reviews-user'): ?>
    <li class="breadcrumb-item active"><?php echo e(tr('user_reviews')); ?></li>
    <?php else: ?>
    <li class="breadcrumb-item active"><?php echo e(tr('provider_reviews')); ?></li>
    <?php endif; ?>
         
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin-assets/css/star-rating-svg.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 

<div class="col-lg-12 grid-margin stretch-card">
        
    <div class="card">

        <div class="card-header bg-card-header ">
        
        <?php if($sub_page == 'reviews-user'): ?>
            <h4 class=""><?php echo e(tr('user_reviews')); ?></h4>
        <?php else: ?>
            <h4 class=""><?php echo e(tr('provider_reviews')); ?></h4>
        <?php endif; ?>
        
        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table id="order-listing" class="table">

                    <thead>
                        <th><?php echo e(tr('s_no')); ?></th>
                        <th><?php echo e(tr('user')); ?></th>
                        <th><?php echo e(tr('provider')); ?></th>
                        <th><?php echo e(tr('date')); ?></th>
                        <th><?php echo e(tr('rating')); ?></th>
                        <th><?php echo e(tr('comment')); ?></th>
                        <th><?php echo e(tr('action')); ?></th>
                    </thead>

                    <tbody>
                     
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $review_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($i+1); ?></td>
                               
                                <td>

                                    <a href="<?php echo e(route('admin.users.view', ['user_id' => $review_details->userDetails->id ?? '0' ] )); ?>">
                                        <?php echo e($review_details->userDetails->name ?? tr('user_not_avail')); ?>

                                    </a>
                                </td>

                                <td>

                                    <a href="<?php echo e(route('admin.providers.view', ['provider_id' => $review_details->providerDetails->id ?? '0' ])); ?>">

                                        <?php echo e($review_details->providerDetails->name ?? tr('provider_not_avail')); ?>

                                    </a>
                                </td>
                                
                                <td>
                                    <?php echo e(common_date($review_details->created_at)); ?>

                                </td>

                                <td>
                                    <div class="my-rating-<?php echo e($i); ?>"></div>
                                </td> 
                                
                                <td><?php echo e(substr($review_details->review, 0, 50)); ?>...</td>

                                <td>
                                
                                    <?php if($sub_page == 'reviews-user'): ?>
                                   
                                        <a class="btn btn-outline-primary" href="<?php echo e(route('admin.reviews.users.view', ['booking_review_id' => $review_details->id])); ?>"><?php echo e(tr('view')); ?></a> 
                                   
                                    <?php else: ?>
                                       
                                        <a class="btn btn-outline-primary" href="<?php echo e(route('admin.reviews.providers.view', ['booking_review_id' => $review_details->id])); ?>"><?php echo e(tr('view')); ?></a> 

                                    <?php endif; ?>                                        
                                       
                                </td>
  
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                             
                    </tbody>
                
                </table>

            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

     <script type="text/javascript" src="<?php echo e(asset('admin-assets/js/jquery.star-rating-svg.min.js')); ?>"> </script>

    <script>
        <?php foreach ($reviews as $i => $review_details) { ?>
            $(".my-rating-<?php echo e($i); ?>").starRating({
                starSize: 25,
                initialRating: "<?php echo e($review_details->ratings); ?>",
                readOnly: true,
                callback: function(currentRating, $el){
                    // make a server call here
                }
            });
        <?php } ?>
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>