 

<?php $__env->startSection('title', tr('view_booking')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.bookings.index')); ?>"><?php echo e(tr('bookings')); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('view_booking')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('content'); ?>
	
	<div class="row ">
		
		<div class="col-12">
          	
          	<div class="card grid-margin ">
          		
          		<div class="card-body">

          		  	<div class="d-flex justify-content-between align-items-center">
	          		    <div class="d-inline-block">
	          		      	<div class="d-lg-flex">
		          		        <h5 class="mb-2 text-uppercase">
		          		        	<b>
		          		        		<?php echo e(tr('booking_id')); ?>: 
		          		        		<span class="text-success">#<?php echo e($booking_details->unique_id); ?></span>
		          		        	</b>
		          		        </h5>
	          		      	</div>

	          		        <p>

          		          		<i class="mdi mdi-clock text-muted"></i>

	          		        	<?php echo e(common_date($booking_details->checkin, Auth::guard('admin')->user()->timezone, 'd M Y H:i')); ?>

	          		        	-
	          		        	<?php echo e(common_date($booking_details->checkout, Auth::guard('admin')->user()->timezone, 'd M Y H:i')); ?>


	          		        </p>

	          		    </div>

	          		    <div class="d-inline-block">
	          		      	<div class="px-3 px-md-4 py-2 rounded text-uppercase text-success">
		          		        <b><?php echo e(booking_status( $booking_details->status)); ?></b>
	          		      	</div>
	          		    </div>

          		  	</div>

          		</div>

          	</div>

        </div>

	</div>

    <div class="row">
        
        <div class="col-12 grid-margin">
          	
          	<div class="card">
	            
	            <div class="card-body">
	              	
	              	<div class="row">

		                <div class="col-md-4 col-sm-6 d-flex justify-content-center border-right">
		                 	<div class="wrapper text-center">
		                    	<h4 class="card-title"><?php echo e(tr('user')); ?></h4>
		                        <img src="<?php echo e($booking_details->user_picture); ?>" alt="image" class="img-lg rounded-circle mb-2"/>
		 		                <h4><?php echo e($booking_details->user_name); ?></h4>

		 		                <a href="<?php echo e(route('admin.users.view', ['user_id' => $booking_details->user_id ])); ?>" class="btn btn-outline-success" ><?php echo e(tr('view')); ?></a>

		 		        	</div>

		                </div>

		                <div class="col-md-4 col-sm-6 d-flex justify-content-center border-right">
		                  <div class="wrapper text-center">
		                    <h4 class="card-title"><?php echo e(tr('parking_space')); ?></h4>
		                    <img src="<?php echo e($booking_details->host_picture); ?>" alt="image" class="img-lg rounded-circle mb-2"/>

		                    <p class="card-description"><?php echo e($booking_details->host_name); ?></p>
		                    <a href="<?php echo e(route('admin.spaces.view', ['host_id' => $booking_details->host_id ])); ?>" class="btn btn-outline-success"><?php echo e(tr('view')); ?></a>

		                  </div>
		                </div>

		                <div class="col-md-4 col-sm-6 d-flex justify-content-center">
		                  <div class="wrapper text-center">
		                    <h4 class="card-title"><?php echo e(tr('provider')); ?></h4>
		                    <img src="<?php echo e($booking_details->provider_picture); ?>" alt="image" class="img-lg rounded-circle mb-2"/>

		                    <p class="card-description"><?php echo e($booking_details->provider_name); ?></p>
		                    <a href="<?php echo e(route('admin.providers.view', ['provider_id' => $booking_details->provider_id ])); ?>" class="btn btn-outline-success"><?php echo e(tr('view')); ?></a>

		                  </div>
		                </div>

	              	</div>

	            </div>

          	</div>

        </div>

    </div>


	<div class="row">
	
		<div class="col-md-4 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
			      	<div class="template-demo">
				        <table class="table mb-0">
				            <tbody>


			            	<tr>
			            	  <td class="pl-0"><?php echo e(tr('user_vehicle_id')); ?></td>
			            	  <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-danger"><?php echo e($booking_details->user_vehicle_id); ?></div></td>
			            	</tr>

			            	<tr>
			            	  <td class="pl-0"><?php echo e(tr('duration')); ?></td>
			            	  <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-danger"><?php echo e($booking_details->duration); ?></div></td>
			            	</tr>

				            <tr>
				              <td class="pl-0"><?php echo e(tr('total_days')); ?></td>
				              <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-primary"><?php echo e($booking_details->total_days); ?></div></td>
				            </tr> 
				            <tr>
				              <td class="pl-0"><?php echo e(tr('per_hour')); ?></td>
				              <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-primary"><?php echo e($booking_details->per_hour); ?></div></td>
				            </tr>

				            <tr>
				              <td class="pl-0"><?php echo e(tr('per_day')); ?></td>
				              <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-primary"><?php echo e($booking_details->per_day); ?></div></td>
				            </tr>
				            <tr>
				              <td class="pl-0"><?php echo e(tr('per_week')); ?></td>
				              <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-info"><?php echo e($booking_details->per_week); ?></div></td>
				            </tr>
				            <tr>
				              <td class="pl-0"><?php echo e(tr('per_month')); ?></td>
				              <td class="pr-0 text-right"><div class="badge badge-pill badge-outline-success"><?php echo e($booking_details->per_month); ?></div></td>
				            </tr>
				          </tbody>
				        </table>
			      	</div>
				</div>
			</div>
		</div>

		<div class="col-md-8 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="preview-list">
						
						<div class="preview-item border-bottom px-0">
							
							<div class="preview-item-content d-flex flex-grow">
								<div class="flex-grow">
									<h6 class="preview-subject"><?php echo e(tr('total')); ?>

										<span class="float-right small">
											<span class="text-muted pr-3"><?php echo e(formatted_amount($booking_details->total)); ?></span>
										</span>
									</h6>
									<!-- <p>Meeting is postponed</p> -->
								</div>
							</div>
						</div>

						<div class="preview-item border-bottom px-0">
							
							<div class="preview-item-content d-flex flex-grow">
								<div class="flex-grow">
									<h6 class="preview-subject"><?php echo e(tr('payment_mode')); ?>

										<span class="float-right small">
											<span class="text-muted pr-3"><?php echo e($booking_details->payment_mode); ?></span>
										</span>
									</h6>
									<!-- <p>Please approve the request</p> -->
								</div>
							</div>
						</div>

						<div class="preview-item border-bottom px-0">
							
							<div class="preview-item-content d-flex flex-grow">
								<div class="flex-grow">
									<h6 class="preview-subject"><?php echo e(tr('admin_amount')); ?>

										<span class="float-right small">
											<span class="text-muted pr-3"><?php echo e(formatted_amount($booking_payment_details->admin_amount)); ?></span>
										</span>
									</h6>
									<!-- <p>Meeting is postponed</p> -->
								</div>
							</div>
						</div>

						<div class="preview-item border-bottom px-0">
							
							<div class="preview-item-content d-flex flex-grow">
								<div class="flex-grow">
									<h6 class="preview-subject"><?php echo e(tr('provider_amount')); ?>

										<span class="float-right small">
											<span class="text-muted pr-3"><?php echo e(formatted_amount($booking_payment_details->provider_amount)); ?></span>
										</span>
									</h6>
									<!-- <p>Meeting is postponed</p> -->
								</div>
							</div>
						</div>

						<div class="preview-item border-bottom px-0">
							
							<div class="preview-item-content d-flex flex-grow">
								<div class="flex-grow">
									<h6 class="preview-subject"><?php echo e(tr('updated_at')); ?>

										<span class="float-right small">
											<span class="text-muted pr-3"><?php echo e(common_date($booking_details->updated_at)); ?></span>
										</span>
									</h6>
									<!-- <p>Hope to see you tomorrow</p> -->
								</div>
							</div>
						</div>	

						<div class="preview-item border-bottom px-0">
							
							<div class="preview-item-content d-flex flex-grow">
								<div class="flex-grow">
									<h6 class="preview-subject"><?php echo e(tr('created_at')); ?>

										<span class="float-right small">
											<span class="text-muted pr-3"><?php echo e(common_date($booking_details->created_at)); ?></span>
										</span>
									</h6>
									<!-- <p>Hope to see you tomorrow</p> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

 	<!-- booking payments details begins -->

 	<?php if($booking_payment_details): ?> 
		
		<div class="row">
			
			<div class="col-md-12 grid-margin stretch-card">
			
			  	<div class="card">
			
				    <div class="card-body">
				      	
				      	<h4 class="card-title"><?php echo e(tr('payment_details')); ?></h4>

				      	<div class="row">
			                
			                <div class="col-md-6 col-sm-6 d-flex justify-content-center border-right">  	
					        	<table class="table mb-0">
						          						          	
						          	<tbody>
							            <tr>
							              <td class="pl-0"><?php echo e(tr('payment_id')); ?></td>
							              <td class="pr-0 text-right"><div class="badge badge-outline-primary">#<?php echo e($booking_payment_details->payment_id); ?></div></td>
							            </tr>

							            <tr>
							              <td class="pl-0"><?php echo e(tr('payment_mode')); ?></td>
							              <td class="pr-0 text-right"><div class="badge badge-outline-info"><?php echo e($booking_payment_details->payment_mode); ?></div></td>
							            </tr>

							            <tr>
							              	<td class="pl-0"><?php echo e(tr('total_time')); ?></td>
							              	<td class="pr-0 text-right">
								              	<div class="badge badge-outline-danger">
								              		<?php echo e($booking_payment_details->total_time); ?> <?php echo e(tr('per_day_text')); ?>

								              	</div>
							              	</td>
							            </tr> 


							            <tr>
							              	<td class="pl-0"><?php echo e(tr('time_price')); ?></td>
							              	<td class="pr-0 text-right">
							              		<div class="badge badge-outline-warning">
							              			<?php echo e(formatted_amount($booking_payment_details->time_price)); ?>

							              		</div>
							              	</td>
							            </tr>

							            <tr>
							              	<td class="pl-0"><?php echo e(tr('base_price')); ?></td>
							              	<td class="pr-0 text-right">
								              	<div class="badge badge-outline-danger">
								              		<?php echo e($booking_payment_details->base_price); ?>

								              	</div>
							              	</td>
							            </tr>

							            <tr>
							              	<td class="pl-0"><?php echo e(tr('per_day')); ?></td>
							              	<td class="pr-0 text-right">
							              		<div class="badge badge-outline-success">
							              			<?php echo e(formatted_amount($booking_payment_details->per_day)); ?>

							              		</div>
							              	</td>
							            </tr>

							            <tr>
				                          	<td class="pl-0"><?php echo e(tr('cleaning_fee')); ?></td>

				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->cleaning_fee)); ?>

				                          		</div>
				                          	</td>
				                        </tr> 
				                        <tr>
				                          	<td class="pl-0"><?php echo e(tr('other_price')); ?></td>
				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->other_price)); ?>

				                          		</div>
				                          	</td>
				                        </tr> 

				                        
				                       
						          	</tbody>

					        	</table>

			                </div>
 							
 							<div class="col-md-6 col-sm-6 d-flex justify-content-center border-right">	
			      	        	<table class="table mb-0">
			      		          						          	
			      		          	<tbody>
			      		          		

			      		          		<tr>
			      		          		  	<td class="pl-0"><?php echo e(tr('paid_date')); ?></td>

			      		          		  	<td class="pr-0 text-right">
			      		          		  		<div class="badge badge-pill badge-outline-primary">
			      		          		  			<?php echo e(common_date($booking_payment_details->paid_date)); ?>

			      		          		  		</div>
			      		          		  	</td>
			      		          		</tr>
			      		          		<tr>
				                          	<td class="pl-0"><?php echo e(tr('tax_price')); ?></td>
				                          	<td class="pr-0 text-right">
					                          	<div class="badge badge-pill badge-outline-primary">
					                          		<?php echo e(formatted_amount($booking_payment_details->tax_price)); ?>

					                          	</div>
				                          	</td>
				                        </tr>
				                        <tr>
				                          	<td class="pl-0"><?php echo e(tr('sub_total')); ?></td>
				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->sub_total)); ?>

				                          		</div>
				                          	</td>
				                        </tr> 
				                       
				                        <tr>
				                          	<td class="pl-0"><?php echo e(tr('actual_total')); ?></td>
				                          	<td class="pr-0 text-right">
					                          	<div class="badge badge-pill badge-outline-primary">
					                          	
					                          		<?php echo e(formatted_amount($booking_payment_details->actual_total)); ?>

					                          	</div>
				                          	</td>
				                        </tr>

			      			            <tr>
				                          	<td class="pl-0"><?php echo e(tr('total')); ?></td>
				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->total)); ?>

				                          		</div>
				                          	</td>
				                        </tr> 

				                        <tr>
				                          	<td class="pl-0"><?php echo e(tr('paid_amount')); ?></td>
				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->paid_amount)); ?>

				                          		</div>
				                          	</td>
				                        </tr>
				                        <tr>
				                          	<td class="pl-0"><?php echo e(tr('admin_amount')); ?></td>
				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->admin_amount)); ?>

				                          		</div>
				                          	</td>
				                        </tr> 

				                        <tr>
				                          	<td class="pl-0"><?php echo e(tr('provider_amount')); ?></td>
				                          	<td class="pr-0 text-right">
				                          		<div class="badge badge-pill badge-outline-primary">
				                          			<?php echo e(formatted_amount($booking_payment_details->provider_amount)); ?>

				                          		</div>
				                          	</td>
				                        </tr>
			      			        </tbody>
			      			    
			      			    </table>
					      	</div>

		                </div>

				    </div>
			  	
			  	</div>
			
			</div>

		</div>
	<?php endif; ?>

	<!-- booking payments details begins -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>