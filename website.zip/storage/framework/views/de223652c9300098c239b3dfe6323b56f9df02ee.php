<div class="col-lg-12 grid-margin stretch-card">

    <div class="row flex-grow">

        <div class="col-12 grid-margin">

            <div class="card">

                <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                <form class="forms-sample" action="<?php echo e(route('admin.amenities.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <?php else: ?>

                <form class="forms-sample" role="form">

                <?php endif; ?> 

                    <?php echo csrf_field(); ?>

                    <div class="card-header bg-card-header ">

                        <h4 class=""><?php echo e(tr('amenity')); ?>


                            <a class="btn btn-secondary pull-right" href="<?php echo e(route('admin.amenities.index')); ?>">
                                <i class="fa fa-eye"></i> <?php echo e(tr('view_amenities')); ?>

                            </a>
                        </h4>

                    </div>

                    <div class="card-body">

                        <input type="hidden" name="amenity_id" id="amenity_id" value="<?php echo e($amenity_details->id); ?>">

                        <div class="row">

                            <div class=" col-md-6">
                               
                                <div class="form-group">

                                    <label for="type"><?php echo e(tr('choose_space_type')); ?> <span class="admin-required">*</span></label>

                                    <select class="form-control select2" id="type" name="type">

                                        <option value=""><?php echo e(tr('choose_space_type')); ?></option>

                                        <?php $__currentLoopData = $host_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host_type_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($host_type_details->key); ?>" <?php if($host_type_details->is_selected == YES): ?> selected <?php endif; ?>><?php echo e($host_type_details->value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                </div>
                            
                            </div>
                                                        
                            <div class="form-group col-md-6">

                                <label for="value"><?php echo e(tr('name')); ?> <span class="admin-required">*</span></label>
                               
                                <input type="text" class="form-control" id="value" name="value" placeholder="<?php echo e(tr('value')); ?>" value="<?php echo e(old('value') ?: $amenity_details->value); ?>" required>

                            </div>

                        </div>

                        <div class="row">


                            <div class="form-group col-md-6">

                                <label><?php echo e(tr('upload_image')); ?> </label>

                                <input type="file" name="picture" class="file-upload-default" accept="image/*" >

                                <div class="input-group col-xs-12">

                                    <input type="file" class="form-control file-upload-info" name="picture" placeholder="<?php echo e(tr('upload_image')); ?>" accept="image/*" >

                                    <div class="input-group-append">
                                        <button class="btn btn-info" type="button"><?php echo e(tr('upload')); ?></button>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="card-footer">

                        <button type="reset" class="btn btn-light"><?php echo e(tr('reset')); ?></button>

                        <?php if(Setting::get('is_demo_control_enabled') == NO ): ?>

                            <button type="submit" class="btn btn-success mr-2"><?php echo e(tr('submit')); ?> </button>

                        <?php else: ?>

                            <button type="button" class="btn btn-success mr-2" disabled><?php echo e(tr('submit')); ?></button>
                            
                        <?php endif; ?>

                    </div>

                </form>

            </div>

        </div>

    </div>
    
</div>