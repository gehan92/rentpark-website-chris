 

<?php $__env->startSection('title', tr('view_spaces')); ?>

<?php $__env->startSection('breadcrumb'); ?>

    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.spaces.index')); ?>"><?php echo e(tr('parking_space')); ?></a></li>

    <li class="breadcrumb-item">
        <a href="<?php echo e(route('admin.spaces.view' , ['host_id' => $host_details->id])); ?>"><?php echo e(tr('view_spaces')); ?></a>
    </li>

    <li class="breadcrumb-item active" aria-current="page">
        <span><?php echo e(tr('gallery')); ?></span>
    </li>
           
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row user-profile">
            
		<div class="col-lg-12 side-right stretch-card">
			
			<div class="card">
			 	
			 	<div class="card-header bg-card-header ">

		            <h4 class="text-uppercase"><b><?php echo e(tr('gallery')); ?> - <a class="text-white" href="<?php echo e(route('admin.spaces.view' , ['host_id' => $host_details->id])); ?>"><?php echo e($host_details->host_name); ?></a> </b>
		            </h4>

        		</div>
				
				<div class="card-body">
					
					<div class="row grid-margin">

						<?php $__currentLoopData = $hosts_galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<div class="col-sm-3">
								
								<img src="<?php echo e($gallery->picture); ?>" alt="" style="width: 200px; height: 200px;">
								<br>										
								<a class="btn btn-outline-primary" style="margin : 10px;" href="<?php echo e(route('admin.spaces.gallery.delete', ['gallery_id' => $gallery->id])); ?>" class="btn btn-primary" onclick="return confirm(&quot;<?php echo e(tr('gallery_delete_confirmation')); ?>&quot;);" title="<?php echo e(tr('delete')); ?>" >
								<i class="fa fa-trash-o"></i>
								</a>

							</div>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
				
				</div>
            
            </div>

		</div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>