## PROVIDER API's: 

### Hosts: 

- Steps

	- Step 1 

	- Step 2

	- Step 3

	- Step 4

	- Step 5

	- Step 6

	- Step 7

	- Step 8

- Draft API 

- Host Save API 

## USER API's: 

- Booking steps complete

- Status handle properly 

- Static data remove


## Common changes 

- Relation handle 

- Delete handle

- Migration changes


